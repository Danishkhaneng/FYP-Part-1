-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 17, 2024 at 11:09 AM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `eduunitydesk`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `password`, `role`) VALUES
(2, 'admin', 'admin123', 'super'),
(9, 'Moez', 'moez', 'coordinator'),
(10, 'Mokish', '9e62d3aa3d8749f610ba0e08700c4b0e', 'coordinator');

-- --------------------------------------------------------

--
-- Table structure for table `communication`
--

CREATE TABLE `communication` (
  `id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `query` text DEFAULT NULL,
  `voucher_number` varchar(255) DEFAULT NULL,
  `feedback` text DEFAULT NULL,
  `q_category` varchar(255) NOT NULL,
  `q_coordinator` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `communication`
--

INSERT INTO `communication` (`id`, `student_id`, `query`, `voucher_number`, `feedback`, `q_category`, `q_coordinator`, `status`) VALUES
(3, 22, 'asdsad', '2', '[{\"role\":\"admin\",\"message\":\"dddddddddddddddd\",\"timestamp\":\"2024-11-09 09:10:35\"},{\"role\":\"student\",\"message\":\"dddddddddd\",\"timestamp\":\"2024-11-09 09:10:40\"},{\"role\":\"student\",\"message\":\"sssss\",\"timestamp\":\"2024-11-09 09:10:43\"},{\"role\":\"student\",\"message\":\"asd\",\"timestamp\":\"2024-11-15 21:45:15\"},{\"role\":\"student\",\"message\":\"asd\",\"timestamp\":\"2024-11-15 21:45:18\"},{\"role\":\"admin\",\"message\":\"a\",\"timestamp\":\"2024-11-16 09:23:10\"}]', 'admission_department', 'admin', 'Resolved'),
(4, 22, 'asd', '3', '[]', 'student_services', 'admin', 'pending'),
(6, 22, 'asd', '5', '[]', 'admission_department', 'ferd', 'pending'),
(7, 22, 'asdasd', '6', '[]', 'student_services', 'admin', 'pending'),
(8, 26, 'ddddddddddddddd', '7', '[]', 'admission_department', 'admin', 'pending'),
(9, 26, '33333333333333333', '8', '[]', 'student_services', 'admin', 'pending'),
(10, 26, 'fffffffffffffffffff44444444444', '9', '[]', 'student_services', 'ferd', 'pending'),
(11, 22, '12313123', '10', '[]', 'student_services', 'admin', 'pending'),
(12, 34, 'how are you', '11', '[]', 'admission_department', 'Moez', 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `id` int(11) NOT NULL,
  `course_name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`id`, `course_name`, `description`, `created_at`) VALUES
(9, 'Math', 'mathematics', '2024-11-16 06:08:27'),
(10, 'Computer Science', 'Computer Science', '2024-11-16 06:08:35'),
(11, 'Software Design & Archit', 'Software Design & Archit', '2024-11-16 06:08:43'),
(12, 'technical business writing', 'technical business writing', '2024-11-16 07:17:08'),
(13, 'Software Requirement Engineering', 'Software Requirement Engineering', '2024-11-16 07:17:33'),
(14, 'Quality Assurance', 'Quality Assurance', '2024-11-16 07:17:45'),
(15, 'Web Engineering', 'Web Engineering', '2024-11-16 07:17:57'),
(16, 'Entrepreneurship', 'Entrepreneurship', '2024-11-16 07:18:12'),
(17, ' Software Design & Archit Lab', 'SE6-1 Software Design & Archit Lab (Male)', '2024-11-16 07:19:10'),
(18, ' Computer Networks ', 'SE6-2 Computer Networks (Male)', '2024-11-16 07:19:28'),
(19, 'Computer Networks ', 'SE6-2 Computer Networks (Male) Lab', '2024-11-16 07:19:53'),
(20, 'Final Year Project-I ', 'SE7-1 Final Year Project-I (Male)', '2024-11-16 07:20:13'),
(21, 'Final Year Project-II', 'SE8-1 Final Year Project-II (Male)', '2024-11-16 07:20:38'),
(22, 'Game Programming ', 'SE7-1 Game Programming (Male)', '2024-11-16 07:20:57'),
(23, 'Software Project Management ', 'SE7-1 Software Project Management (Male)', '2024-11-16 07:21:15'),
(24, 'Information Security ', 'SE8-1 Information Security (Male)', '2024-11-16 07:21:34'),
(25, 'Professional Practices ', 'SE8-1 Professional Practices (Male)', '2024-11-16 07:21:52'),
(26, 'Simulation and Modeling', 'SE8-1 Simulation and Modeling (Male)', '2024-11-16 07:22:11'),
(27, 'Principles of Digital Mkt ', 'SE8-2 Principles of Digital Mkt (Male)', '2024-11-16 07:22:27');

-- --------------------------------------------------------

--
-- Table structure for table `course_chat`
--

CREATE TABLE `course_chat` (
  `id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `chat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `course_chat`
--

INSERT INTO `course_chat` (`id`, `course_id`, `teacher_id`, `chat`) VALUES
(1, 4, 5, '[{\"student_name\":\"jawad\",\"date\":\"2024-11-09 08:02:35\",\"message\":\"asdasdasd\",\"student_id\":\"23\"},{\"student_name\":\"jawad\",\"date\":\"2024-11-09 08:02:38\",\"message\":\"321eqwasd\",\"student_id\":\"23\"},{\"student_name\":\"jawad\",\"date\":\"2024-11-09 08:06:05\",\"message\":\"asad\",\"student_id\":\"23\"}]'),
(2, 10, 5, '[{\"student_name\":\"DANISH REHMAN\",\"date\":\"2024-11-16 10:55:13\",\"message\":\"this danish\",\"student_id\":\"34\"},{\"student_name\":\"Sami Ullah\",\"date\":\"2024-11-16 10:56:56\",\"message\":\"this sami ullah\",\"student_id\":\"28\"}]');

-- --------------------------------------------------------

--
-- Table structure for table `course_file`
--

CREATE TABLE `course_file` (
  `id` int(11) NOT NULL,
  `file` varchar(255) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `notices`
--

CREATE TABLE `notices` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `date` date DEFAULT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `notices`
--

INSERT INTO `notices` (`id`, `title`, `content`, `date`, `image`) VALUES
(5, 'Notice 4Notice 1Notice 1Notice 1', '\r\nikram', '2024-09-27', 'uploads/673868f3e6e13_riphah1.jpg'),
(6, 'Notice Notice 1Notice 1Notice 1', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. In in ex consectetur, sodales lacus eget, volutpat nunc. Proin sollicitudin nisl nisi, nec congue diam blandit eu. Donec faucibus justo ut varius bibendum. Suspendisse lobortis ornare mi a vehicula. Pellentesque nec risus ac enim vulputate tempus sed nec sem. Vestibulum vel felis a metus fermentum egestas. Etiam molestie ornare metus. Donec vestibulum nibh sed tortor facilisis, ut finibus urna iaculis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Nullam consectetur eleifend massa, in elementum nunc. Donec semper, justo vitae maximus convallis, ex nisi aliquam erat, scelerisque sagittis magna est a erat. Duis eget feugiat sem. Duis ac ultricies nisi, non elementum urna. Nam bibendum magna arcu, a sodales elit placerat rutrum. Etiam bibendum placerat nisi a malesuada.', '2024-09-12', 'uploads/66e6dfce385bf_alphagamma-bett-show-2020-opportuniries-min-1024x576.jpg'),
(7, 'Notice 6Notice 1Notice 1Notice 1Notice 1Notice 1', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. In in ex consectetur, sodales lacus eget, volutpat nunc. Proin sollicitudin nisl nisi, nec congue diam blandit eu. Donec faucibus justo ut varius bibendum. Suspendisse lobortis ornare mi a vehicula. Pellentesque nec risus ac enim vulputate tempus sed nec sem. Vestibulum vel felis a metus fermentum egestas. Etiam molestie ornare metus. Donec vestibulum nibh sed tortor facilisis, ut finibus urna iaculis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Nullam consectetur eleifend massa, in elementum nunc. Donec semper, justo vitae maximus convallis, ex nisi aliquam erat, scelerisque sagittis magna est a erat. Duis eget feugiat sem. Duis ac ultricies nisi, non elementum urna. Nam bibendum magna arcu, a sodales elit placerat rutrum. Etiam bibendum placerat nisi a malesuada.', '2024-09-20', 'uploads/66e6dff05395f_28032023012127PM-Shutterstock_2129585300-min.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `saved_courses`
--

CREATE TABLE `saved_courses` (
  `id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `course_id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `saved_courses`
--

INSERT INTO `saved_courses` (`id`, `student_id`, `course_id`, `teacher_id`) VALUES
(4, 34, 10, 5),
(5, 28, 10, 5);

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `contact` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `profile_image` varchar(255) NOT NULL,
  `reg_no` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `name`, `email`, `contact`, `password`, `profile_image`, `reg_no`, `status`) VALUES
(22, 'Zaid Ahmad', 'zaidahmad22629@gmail.com', '03325459219', '$2y$10$6nAZ62mKJF86yRascKKjbu5eUOONyYv2IBuhfgvI30sIaskg4kbrm', 'uploads/17311399081231231.png', '22629', 'approved'),
(26, 'ahmed', 'ahmed@gmail.com', '12312312', '$2y$10$xv5hGnIsEVbEDPN0NXCiOO9rsPS5UQNS8uh8VCSyP8Dns4vrgg5Vi', '', '22620', 'approved'),
(27, 'ikram Aziz', 'ikramaziz@gmail.com', '03337989800', '$2y$10$k8CE8tMz1F1q/G9cvo7/JO6HGmTp683gn/CgytgGe8pkYLQ5KF74i', '', '22621', 'approved'),
(28, 'Sami Ullah', 'samiulla22622@gmail.com', '03325459219', '$2y$10$SID2vuzKfoMciEo/KFU5uOa6CM8VoOoA8qq3UC06XH6zeqcGtPeKW', '', '22622', 'approved'),
(29, 'Hassan ullah', 'hassanullah22623@gmail.com', '03325459219', '$2y$10$Qd9bEmc2vHeCGQJxprDdleT4rmBjelk6O/bJ20gQ1apMc0VYNm5cS', '', '22623', 'approved'),
(30, 'Qais ahmad', 'qaisahmad22624@gmail.com', '03325459219', '$2y$10$GZO.pl6bCwnBfP9G56Jod.lwHsRTuZLHfQhUCAo3h0Cr0r/brtcTe', '', '22624', 'approved'),
(31, 'Salaar Ahmad Khan', 'sallarahmadkhan22625@gmail.com', '03337989800', '$2y$10$oOu7p2QG9Fp9ym.oHSoiaujylT3KAs7EYKAlItW9prMNrJCvs/kmW', '', '22625', 'approved'),
(32, 'Atiq khan', 'atiqkhan22626@gmail.com', '03325459219', '$2y$10$4sv22gBV3.FcywJPC8ItW.nUiQErJEAWoxUP9IPViGP27iiUSIqEG', '', '22626', 'approved'),
(33, 'Hamza Rehman', 'hamzarehman22627@gmail.com', '03325459219', '$2y$10$q7UYCtuyZwUagDgk04cGo.vBL39FnkpbOfjBHKejnF.0pe.z/ql8W', '', '22627', 'approved'),
(34, 'DANISH REHMAN', 'danishrehman22628@gmail.com', '03337989800', '$2y$10$J3XMNB6N4ZMujAE2wBC1mO.U3nRA8Uvozmf3DQmd7qHuttB7FtIma', '', '22628', 'approved'),
(35, 'DANISH REHMAN', 'danishrehman22aa628@gmail.com', '03337989800', '$2y$10$J6O9UwjtFI7DcU/YDizr/OE1YR69d0Zf5EetKenH8S8HGBlP0odhq', '', 'dsda', 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE `teachers` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `experience` varchar(255) DEFAULT NULL,
  `course_id` int(11) DEFAULT NULL,
  `profile_image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`id`, `email`, `password`, `name`, `contact`, `experience`, `course_id`, `profile_image`) VALUES
(5, 'jawaidiqbal23744@gmail.com', '23744', 'jawaid iqbal', '23744', '5', 10, 'uploads/Screenshot (3).png'),
(6, 'shahbazhassan23798@gmail.com', '23798', 'shahbaz hassan', '1234567', '2', 9, ''),
(7, 'saudkhan23622@gmail.com', '23522', 'Saud khan', '123245', '23', 23, ''),
(8, 'ihtesham23796@gmail.com', '23796', 'Ihtesham husssain', '23791', '6', 15, ''),
(9, 'razashehroz23794@gmail.com', '23794', 'Rana Shehroz', '23791', '6', 16, ''),
(10, 'abdulmaten23795@gmail.com', '23795', 'Abdul Mateen', '03337989800', '6', 22, ''),
(11, 'rizwanbinfaiz23796@gmail.com', '23796', 'Rizwan Bin Faiz', '03337989800', '6', 14, ''),
(12, 'sharjeelgillani23797@gmail.com', '23797', 'Sharjeel Gillani', '03337989800', '7', 19, ''),
(13, 'muhammadahmad23798@gmail.com', '23798', 'muhammad Ahmad', '03337989800', '5', 12, ''),
(14, '22628@students.riphah.edu.pk', '2379611@abs', 'jawaid iqbal @112', 'as@', '1', 27, '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `communication`
--
ALTER TABLE `communication`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `course_chat`
--
ALTER TABLE `course_chat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `course_file`
--
ALTER TABLE `course_file`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notices`
--
ALTER TABLE `notices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `saved_courses`
--
ALTER TABLE `saved_courses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `communication`
--
ALTER TABLE `communication`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `course_chat`
--
ALTER TABLE `course_chat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `course_file`
--
ALTER TABLE `course_file`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `notices`
--
ALTER TABLE `notices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `saved_courses`
--
ALTER TABLE `saved_courses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `teachers`
--
ALTER TABLE `teachers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
