<?php
include 'php/db.php';
session_start();
if ($_SERVER['REQUEST_METHOD'] == 'POST' ) {
    
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $contact = mysqli_real_escape_string($conn, $_POST['contact']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $reg_no = mysqli_real_escape_string($conn, $_POST['reg_no']);
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

 // Validate email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $_SESSION['message'] = 'Invalid email format. Please enter a valid email address.';
        header('Location: index.php');
        exit();
    }
    // Check if email already exists
    $check_email = "SELECT * FROM students WHERE email='$email'";
    $email_result = mysqli_query($conn, $check_email);

    // Check if email already exists
    $check_reg_no = "SELECT * FROM students WHERE reg_no='$reg_no'";
    $reg_no_result = mysqli_query($conn, $check_reg_no);

    if (mysqli_num_rows($email_result) > 0) {
            $_SESSION['message'] = 'Email already exists! Please use another email.';
            header('Location: index.php');
            exit();
    } 
    elseif (mysqli_num_rows($reg_no_result) > 0) {
            $_SESSION['message'] = 'Registration Number already exists.';
            header('Location: index.php');
            exit();
    } else {
        // Insert new student into the database
        $sql = "INSERT INTO students (name, email, contact, password, reg_no, status) VALUES ('$name', '$email', '$contact', '$hashed_password', '$reg_no', 'pending')";
        if (mysqli_query($conn, $sql)) {
        	 $_SESSION['message'] = 'Registration successful! You can now login After Account Approval.';
            header('Location: index.php');
            exit();
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }
    }
}
mysqli_close($conn);
?>
