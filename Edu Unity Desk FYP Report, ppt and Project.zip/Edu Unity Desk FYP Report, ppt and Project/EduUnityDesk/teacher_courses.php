<!DOCTYPE html>
<html lang="en">

<?php include('includes/head.php') ?>
<?php
if (!isset($_SESSION['teacher'])) {
    header('Location: index.php');
    exit();
}

include 'php/db.php';

// Fetch student information
$email = $_SESSION['teacher'];
$sql = "SELECT * FROM teachers WHERE email = '$email'";
$result = mysqli_query($conn, $sql);
$teacher = mysqli_fetch_assoc($result);

if ($teacher['course_id']) {
	$course_id = $teacher['course_id'];
	$course_name_sql = "SELECT course_name FROM courses WHERE id = $course_id";
	$course_name_result = mysqli_query($conn, $course_name_sql);
	$course_name_row = mysqli_fetch_assoc($course_name_result);
}

                                            
?>

<body>
    <?php include('includes/spinner.php') ?>
    <?php include('includes/navbar.php') ?>
    <?php include('includes/show_message.php') ?>

   <!-- Add Courses Tables Here -->
   <div class="container my-3 py-3">
  
   	<?php
   	if (isset($course_name_row['course_name'])) {
   		?>
   		<h1 class="text-center text-danger">Course Name : <?php echo htmlspecialchars($course_name_row['course_name']);  ?><a href="teacher_dashboard.php" class="btn btn-primary btn-md" style="float:right;">
   		Back
   	</a>

   </h1>
   		<?php
   	}
   	?>
   
   	<hr>

   	<div class="my-3">
   		<form action="add_file.php" method="POST" enctype="multipart/form-data">
		    <input type="hidden" name="course_id" value="<?php echo htmlspecialchars($course_id); ?>">
		    <input type="hidden" name="teacher_id" value="<?php echo htmlspecialchars($teacher['id']); ?>">
		    <input type="file" name="file" required>
		    <button class="btn btn-md btn-primary" type="submit">Upload File</button>
		    <p>Only PDF are allowed</p>
		</form>
   	</div>
   	<hr>
   
   	<table id="favCoursesTable" class="table table-striped table-hover">
                    <thead class="thead-dark">
                        <tr>
                            <th>File Name</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    	<?php 
						$sql = "SELECT * FROM course_file WHERE course_id = $course_id";
							$result = mysqli_query($conn, $sql);

							while ($row = mysqli_fetch_assoc($result)) {
							    echo '<tr>';
							    echo '<td>' . htmlspecialchars($row['file']) . '</td>';
							    echo '<td>
							            <a class="btn btn-warning btn-sm mx-1" href="' . htmlspecialchars($row['file']) . '" download>Download</a>
							            <a class="btn btn-danger btn-sm mx-1" href="delete_file.php?id=' . $row['id'] . '">Delete</a>
							          </td>';
							    echo '</tr>';
							}
                    	?>
					
                      </tbody>
                </table>

               
   <!-- Add Courses Tables Here -->

    <?php include('includes/footer.php') ?>
</body>

</html>