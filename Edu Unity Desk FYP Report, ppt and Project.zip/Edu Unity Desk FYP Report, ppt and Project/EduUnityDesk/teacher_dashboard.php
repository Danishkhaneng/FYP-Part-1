<!DOCTYPE html>
<html lang="en">

<?php include('includes/head.php') ?>
<?php
if (!isset($_SESSION['teacher'])) {
    header('Location: index.php');
    exit();
}

include 'php/db.php';

// Fetch student information
$email = $_SESSION['teacher'];
$sql = "SELECT * FROM teachers WHERE email = '$email'";
$result = mysqli_query($conn, $sql);
$teacher = mysqli_fetch_assoc($result);
?>

<body>
    <?php include('includes/spinner.php') ?>
    <?php include('includes/navbar.php') ?>
    <?php include('includes/show_message.php') ?>


  <div class="container mt-5">
    <h1>Welcome to Teacher Dashboard, <?php echo htmlspecialchars($teacher['name']); ?></h1>

    <!-- Card Row -->
    <div class="row my-5 py-5">
        <!-- Card for My Account -->
        <div class="col-md-6">
            <div class="card dashboard-cards-all text-center">
                <div class="card-icon mt-3">
                    <i class="fa fa-user-circle fa-3x text-primary"></i>
                </div>
                <div class="card-body">
                    <h5 class="card-title">My Account</h5>
                    <p class="card-text">View and update your account information.</p>
                    <!-- Button to open My Account modal -->
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#myAccountModalTeacher">View Account</button>
                </div>
            </div>
        </div>

       <!-- Card for Courses -->
       <div class="col-md-6">
            <div class="card dashboard-cards-all text-center">
                <div class="card-icon mt-3">
                    <i class="fa fa-user-circle fa-3x text-primary"></i>
                </div>
                <div class="card-body">
                    <h5 class="card-title">Course</h5>
                    <p class="card-text">View and manage your course.</p>
                    <a class="btn btn-primary" href="teacher_courses.php">View Course</a>
                </div>
            </div>
        </div>
       
    </div>
</div>

<!-- My Account Modal -->
<div class="modal fade" id="myAccountModalTeacher" tabindex="-1" aria-labelledby="myAccountModalTeacherLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="myAccountModalTeacherLabel">My Account</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <!-- Account information form or content goes here -->
                <form id="accountFormTeacher" method="POST" action="update_account.php">

                      <!-- Display the current profile image if available -->
                    <div class="mb-3">
                        <?php if (!empty($teacher['profile_image'])): ?>
                            <img src="<?php echo htmlspecialchars($teacher['profile_image']); ?>" alt="Profile Image" class="img-thumbnail" width="150">
                        <?php else: ?>
                           <img src="uploads/default-profile.png" alt="Profile Image" class="img-thumbnail" width="150">
                        <?php endif; ?>
                    </div>

                     <!-- Other form fields remain the same -->
                     <div class="mb-3">
                        <label for="profile_image" class="form-label">Profile Image</label>

                        <?php if (!empty($teacher['profile_image'])): ?>
                           <input type="file" name="profile_image" value="<?php echo htmlspecialchars($teacher['profile_image']); ?>" class="form-control" id="profile_image">
                        <?php else: ?>
                          <input type="file" name="profile_image" value="uploads/default-profile.png"  class="form-control" id="profile_image">
                        <?php endif; ?>
                    </div>
                    <div class="mb-3">
                        <label for="name" class="form-label">Name</label>
                        <input type="text" name="name" class="form-control" id="name" value="<?php echo htmlspecialchars($teacher['name']); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" name="email" class="form-control" id="email" value="<?php echo htmlspecialchars($teacher['email']); ?>">
                    </div>
                   
                   
                    <div class="mb-3">
                        <label for="old_password" class="form-label">Old Password</label>
                        <input type="password" class="form-control" name="old_password" id="old_password">
                    </div>

                    <div class="mb-3">
                        <label for="password" class="form-label">New Password</label>
                        <input type="password" class="form-control" name="password" id="password">
                    </div>
                   <button type="submit" class="btn btn-primary">Save Changes</button>

                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>





<!-- Custom Popup HTML -->
<div id="customAlert" style="display: none;">
    <div id="customAlertContent">
        <p id="alertMessage"></p>
        <button id="reloadButton">Reload</button>
    </div>
</div>

<!-- Custom Popup CSS -->
<style>
    #customAlert {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 99999999999999999999999;
    }

    #customAlertContent {
        background-color: white;
        padding: 20px;
        border-radius: 10px;
        text-align: center;
    }

    #reloadButton {
        margin-top: 10px;
        padding: 10px 20px;
        background-color: #007bff;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }

    #reloadButton:hover {
        background-color: #0056b3;
    }
</style>

<script>
	 // AJAX form submission
        document.getElementById('accountFormTeacher').addEventListener('submit', function(event) {
            event.preventDefault();

            var formData = new FormData(this);

            fetch('update_account_teacher.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.text())
            .then(result => {
            	  // Set the custom alert message
        document.getElementById('alertMessage').textContent = result + " Reload to see changes.";
        
        // Display the custom alert
        document.getElementById('customAlert').style.display = 'flex';

        // Add event listener to the reload button to redirect to student_dashboard.php
        document.getElementById('reloadButton').addEventListener('click', function() {
            window.location.href = 'teacher_dashboard.php';
        });
            })
            .catch(error => console.error('Error:', error));
        });
</script>


    <?php include('includes/footer.php') ?>
</body>

</html>