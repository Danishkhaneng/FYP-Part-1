
<!DOCTYPE html>
<html lang="en">

<?php include('includes/head.php') ?>
<?php
include 'php/db.php';

if (!isset($_SESSION['student'])) {
    header('Location: index.php');
    exit();
}

// Get the query ID from the URL
$query_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Fetch the query details from the communication table
$sqlQuery = "SELECT * FROM communication WHERE id = '$query_id'";
$resultQuery = mysqli_query($conn, $sqlQuery);
$queryDetails = mysqli_fetch_assoc($resultQuery);

// If the query does not exist, redirect to the communication list
if (!$queryDetails) {
    header('Location: student_course.php');
    exit();
}

// Decode the feedback JSON
$feedback = json_decode($queryDetails['feedback'], true);
?>

<body>
    <?php include('includes/spinner.php') ?>
    <?php include('includes/navbar.php') ?>
    <?php include('includes/show_message.php') ?>

    <div class="container my-5">
        <h2 class="text-center">Query Details</h2>
        <div class="card mb-4">
            <div class="card-header">
                <strong>Query:</strong> <?php echo htmlspecialchars($queryDetails['query']); ?>
            </div>
            <div class="card-body">
                <p><strong>Voucher Number:</strong> <?php echo htmlspecialchars($queryDetails['voucher_number']); ?></p>
                <p><strong>Status:</strong> <?php echo htmlspecialchars($queryDetails['status']); ?></p>
                <p><strong>Category:</strong> 
                    <?php
                            if ($queryDetails['q_category'] == 'student_services') {
                               echo 'Student Services';
                            }elseif ($queryDetails['q_category'] == 'admission_department') {
                                echo 'Admission Department';
                            }elseif ($queryDetails['q_category'] == 'fees_department') {
                                echo 'Fees Department';
                            }

                            ?>
                </p>
                <p><strong>Coordinator:</strong> <?php echo htmlspecialchars($queryDetails['q_coordinator']); ?></p>
            </div>
        </div>

        <h3 class="text-center">Feedback</h3>
        <div class="card">
            <div class="card-body">
                <ul class="chat-list list-unstyled">
                    <?php
                    if (!empty($feedback)) {
                        foreach ($feedback as $f) {
                            ?>
                            <li class="in mb-3 d-flex justify-content-start">
                                <div class="chat-body bg-light text-dark p-3 rounded shadow-sm" style="width:100%">
                                    <div class="chat-message">
                                        <small class="text-muted"><?php echo htmlspecialchars($f['timestamp']); ?></small>
                                        <?php
                                        	if ($f['role'] != 'student') {
                                        		?>
                                        		 <strong><p class="mb-1">Help Desk</p></strong>
                                        		<?php
                                        	}else{
                                        		?>
                                        		 
                                        		 <strong><p class="mb-1">Me</p></strong>

                                        		<?php
                                        	}
                                         ?>
                                        <p><?php echo htmlspecialchars($f['message']); ?></p>
                                    </div>
                                </div>
                            </li>
                            <?php
                        }
                        ?>
                        <div class="my-4">
            <h4>Add Feedback</h4>
            <form method="POST" action="add_feedback.php">
                <input type="hidden" name="query_id" value="<?php echo $query_id; ?>" />
                <div class="form-group">
                    <label for="feedback">Feedback Message</label>
                    <textarea name="feedback" class="form-control" id="feedback" rows="3" required></textarea>
                </div>
                <button type="submit" class="btn btn-primary">Submit Feedback</button>
                <a href="ask_query.php" class="btn btn-secondary">Back</a>
            </form>
        </div>
    </div>
                        <?php
                    } else {
                        echo '<li class="text-center">No feedback yet.</li>';
                    }
                    ?>
                </ul>
            </div>
        </div>

        

    <?php include('includes/footer.php') ?>
</body>
</html>
