<?php
include 'php/db.php';
session_start();
if (isset($_SESSION['student'])) {
    header('Location: index.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    // Fetch student data from the database
    $sql = "SELECT * FROM students WHERE email='$email'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        $student = mysqli_fetch_assoc($result);
        
        // Verify the password
        if (password_verify($password, $student['password'])) {
            if ($student['status'] != 'approved') {
                  $_SESSION['message'] = 'Student Not Approved.';
                        header('Location: index.php');
                        exit();
            }
            $_SESSION['student'] = $student['email'];
            $_SESSION['student_id'] = $student['student_id'];
            $_SESSION['message'] = 'Welcome Back!';
            header('Location: student_dashboard.php');
            exit();
        } else {
             $_SESSION['message'] = 'Incorrect password!';
            header('Location: index.php');
            exit();
        }
    } else {
         $_SESSION['message'] = 'No account found with this email!';
            header('Location: index.php');
            exit();
    }
}
mysqli_close($conn);
?>
