<!DOCTYPE html>
<html lang="en">

<?php include('includes/head.php') ?>
<?php
include 'php/db.php';

if (!isset($_SESSION['student'])) {
    header('Location: index.php');
    exit();
}

// Fetch student information
$email = $_SESSION['student'];
$sql = "SELECT * FROM students WHERE email = '$email'";
$result = mysqli_query($conn, $sql);
$student = mysqli_fetch_assoc($result);

// Fetch communication records for the current student
$student_id = $student['id'];
$sqlComm = "SELECT * FROM communication WHERE student_id = '$student_id'";
$resultComm = mysqli_query($conn, $sqlComm);



// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Sanitize input
    $query = mysqli_real_escape_string($conn, $_POST['query']);
    $q_coordinator = mysqli_real_escape_string($conn, $_POST['q_coordinator']);
    $q_category = mysqli_real_escape_string($conn, $_POST['q_category']);
    $student_id = $student['id'];


    $n = 4;

    $characters = '0123456789';
    $randomString = '#';

    for ($i = 0; $i < $n; $i++) {
        $index = random_int(0, strlen($characters) - 1);
        $randomString .= $characters[$index];
    }



$sqlLastData = "SELECT * FROM communication ORDER BY id DESC LIMIT 1";
$result = mysqli_query($conn, $sqlLastData);

if ($result && mysqli_num_rows($result) > 0) {
    $lastRow = mysqli_fetch_assoc($result);
    $voucher_number =  $lastRow['id'];

} else {
    $voucher_number = 1;
}


    // Insert the new query into the communication table
    $sqlInsert = "INSERT INTO communication (student_id, query, voucher_number, feedback, q_coordinator ,q_category, status) VALUES ('$student_id', '$query', '$voucher_number', '[]', '$q_coordinator', '$q_category', 'pending')";
    
    if (mysqli_query($conn, $sqlInsert)) {
        $_SESSION['message'] = "Query successfully added!";
        header('Location: ask_query.php'); // Redirect to the main page after submission
        exit();
    } else {
        $_SESSION['message'] = "Error: " . mysqli_error($conn);
    }
}
?>
<body>
    <?php include('includes/spinner.php') ?>
    <?php include('includes/navbar.php') ?>
    <?php include('includes/show_message.php') ?>

    <!-- Communication Table -->
    <div class="container mt-5">
        <h5 class="text-center">Your Queries.
                      
                <strong class="text-primary"> (Your Pending Queries. : 

                <?php
               $sql7="SELECT * FROM communication WHERE status = 'pending' AND student_id = $student_id";

                if ($result7=mysqli_query($conn,$sql7))
                  {
                  // Return the number of rows in result set
                  $rowcount7=mysqli_num_rows($result7);
                  printf($rowcount7);
                  }
                ?>
                )
             </strong>   

              <strong class="text-danger"> (Total Pending Queries : 

                <?php
               $sql8="SELECT * FROM communication WHERE status = 'pending'";

                if ($result8=mysqli_query($conn,$sql8))
                  {
                  // Return the number of rows in result set
                  $rowcount8=mysqli_num_rows($result8);
                  printf($rowcount8);
                  // Free result set
                  // mysqli_free_result($result7);
                  }
                ?>
                )
             </strong> 

                    </h5>
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                   
                    <th>Voucher Number</th>
                     <th>Query</th>
                    <th>Category</th>
                    <th>Coordinator</th>
                    <th>Status</th>
                    <th>Feedback</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if (mysqli_num_rows($resultComm) > 0) {
                    while ($row = mysqli_fetch_assoc($resultComm)) {
                        // Decode the feedback JSON
                        $feedback = json_decode($row['feedback'], true);
                        ?>
                        <tr>
                            <td>#<?php echo htmlspecialchars($row['voucher_number']); ?></td>
                            <td><?php echo htmlspecialchars($row['query']); ?></td>

                            <td><?php
                            if ($row['q_category'] == 'student_services') {
                               echo 'Student Services';
                            }elseif ($row['q_category'] == 'admission_department') {
                                echo 'Admission Department';
                            }elseif ($row['q_category'] == 'fees_department') {
                                echo 'Fees Department';
                            }

                            ?></td>
                            <td><?php echo htmlspecialchars($row['q_coordinator']); ?></td>

                            <?php 
                            $total_pending = '';
                            if ($row['status'] == 'pending') {
                                    $user_id = $row['id'];
                        $query1 = "SELECT COUNT(*) AS total_pending 
                      FROM communication 
                      WHERE id < '$user_id' AND status = 'pending'";
                            $result2 = mysqli_query($conn, $query1);

                            if ($result2) {
                                $data = mysqli_fetch_assoc($result2);
                                $total_pending = $data['total_pending']; // Total count of pending records
                               $total_pending = '(Query At #'. $total_pending + 1 .')';
                            }
                            }
                       

                            ?>
                            <td><?php echo htmlspecialchars($row['status']) ?> <strong class="text-danger"> <?php echo $total_pending ?></strong></td>
                            <td>
                                <?php
                                // Loop through feedback messages and display them
                                if (!empty($feedback)) {
                                    foreach ($feedback as $f) {
                                        echo "<strong>" . htmlspecialchars($f['role']) . ":</strong> ";
                                        echo htmlspecialchars($f['message']) . " <small class='text-muted'>(" . htmlspecialchars($f['timestamp']) . ")</small><br>";
                                    }
                                } else {
                                    echo "No feedback yet";
                                }
                                ?>
                            </td>
                            <td>
                                <!-- Action: View Query -->
                                <a href="view_query.php?id=<?php echo $row['id']; ?>" class="btn btn-primary btn-sm">View/Chat  </a>
                            </td>
                        </tr>
                        <?php
                    }
                } else {
                    echo '<tr><td colspan="4" class="text-center">No queries found</td></tr>';
                }
                ?>
            </tbody>
        </table>

        <div class="container my-5">
            <h2 class="text-center">Add New Query</h2>
         
            <form method="POST" action="">

            
                 <div class="form-group my-3">
                    <label>Category</label>
                     <select id="q_category" name="q_category" class="form-control form-control-user" required>
                        <option value="">Select</option>
                        <option value="admission_department">Admission Department</option>
                        <option value="student_services">Student Services</option>
                        <option value="fees_department">Fees Department</option>
                    </select>
                </div>


                <div class="form-group my-3">
                    <label>Select Coordinator</label>
                    <select id="q_coordinator" name="q_coordinator" class="form-control form-control-user" required>
                      <option value="">Select</option>

                         <?php 
                            $sqlComm1 =  "SELECT name FROM admin";
                            $resultComm1 = mysqli_query($conn, $sqlComm1);
                              if (mysqli_num_rows($resultComm1) > 0) {
                                while ($row1 = mysqli_fetch_assoc($resultComm1)) {
                                         echo "<option value='" . $row1['name'] . "'>" . $row1['name'] . "</option>";
                                }
                            }else {
                                echo "<option value=''>No coordinators found</option>";
                            }
                        ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="query">Query</label>
                    <textarea name="query" class="form-control" id="query" rows="5" required></textarea>
                </div>
   <p class="my-3 text-danger"><small><strong>Note: Voucher Will be added automatically</strong></small></p>
                <button type="submit" class="btn btn-primary my-3">Submit Query</button>
                <a href="student_course.php" class="btn btn-secondary">Cancel</a>
            </form>

        </div>
    </div>

    <?php include('includes/footer.php') ?>
</body>
</html>
