<!DOCTYPE html>
<html lang="en">

<?php include('includes/head.php') ?>
<style type="text/css">

/* Ensures that all items within the row are equal height */
.servicesss .row.g-4 {
    display: flex;
    flex-wrap: wrap;
}

/* Makes each .service-item a flexible column */
.servicesss .service-item {
    display: flex;
    flex-direction: column;
    height: 100%;
}

/* Expands the content container to occupy remaining space */
.servicesss .service-item .p-4 {
    flex-grow: 1;
}



    @media only screen and (max-width: 600px) {
     .fs-5{
        font-size: 1rem!important;
     }
     .text-for-mobile{
        width: 270px;
     }
    }
</style>
<body>
    <?php include('includes/spinner.php') ?>
    <?php include('includes/navbar.php') ?>
    <?php include('includes/show_message.php') ?>

    <!-- Carousel Start -->
    <div class="container-fluid p-0 mb-5">
        <div class="owl-carousel header-carousel position-relative">
            <div class="owl-carousel-item position-relative">
                <img class="img-fluid" src="img/carousel-1.jpg" alt="">
                <div class="position-absolute top-0 start-0 w-100 h-100 d-flex align-items-center" style="background: rgba(24, 29, 56, .7);">
                    <div class="container">
                        <div class="row justify-content-start">
                            <div class="col-sm-10 col-lg-8 mt-3">
                                <h5 class="text-primary text-uppercase mb-3 animated slideInDown">Edu Unity Desk</h5>
                                <h1 class="display-3 text-white animated slideInDown">The Best Online Platform</h1>
                                <p class="text-for-mobile fs-5 text-white mb-4 pb-2">In the rapidly evolving landscape of education, effective communication andseamless coordination are fundamental to fostering a conducive learningenvironment. Acknowledging the diverse stakeholders involved – including students, teachers, and staff – presents an opportunity to revolutionize the educational experience through innovative solutions</p>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="owl-carousel-item position-relative">
                <img class="img-fluid" src="img/carousel-2.jpg" alt="">
                <div class="position-absolute top-0 start-0 w-100 h-100 d-flex align-items-center" style="background: rgba(24, 29, 56, .7);">
                    <div class="container">
                        <div class="row justify-content-start">
                            <div class="col-sm-10 col-lg-8 mt-3">
                                <h5 class="text-primary text-uppercase mb-3 animated slideInDown">Edu Unity Desk</h5>
                                <h1 class="display-3 text-white animated slideInDown">Get Educated Online From Your Home</h1>
                                <p class="text-for-mobile fs-5 text-white mb-4 pb-2">In the rapidly evolving landscape of education, effective communication andseamless coordination are fundamental to fostering a conducive learningenvironment. Acknowledging the diverse stakeholders involved – including students, teachers, and staff – presents an opportunity to revolutionize the educational experience through innovative solutions</p>
                              

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Carousel End -->


   <div class="servicesss container-xxl py-5">
    <div class="container">
        <div class="row g-4">
            <!-- Service 1 -->
            <div class="col-lg-4 col-sm-4 wow fadeInUp" data-wow-delay="0.1s">
                <div class="service-item text-center pt-3" data-bs-toggle="modal" data-bs-target="#loginModaTeachersDetails">
                    <div class="p-4">
                        <i class="fa fa-3x fa-graduation-cap text-primary mb-4"></i>
                        <h5 class="mb-3">Skilled Teachers</h5>
                        <p> 
                        Subject Expertise: Deep knowledge of their academic discipline to teach advanced concepts. <br>
                        Pedagogical Skills: Ability to design effective courses, deliver engaging lectures, and implement innovative teaching methods. <br>
                        Assessment Design: Creating exams, projects, and assignments that effectively evaluate students’ understanding. <br>
                        Adaptability: Using varied teaching strategies to accommodate different learning styles and technologies. <br>
                        Feedback Skills: Providing constructive and timely feedback to support student learning. <br>
                    </p>   
                       </div>
                </div>
            </div>
            <!-- Service 2 -->
            <div class="col-lg-4 col-sm-4 wow fadeInUp" data-wow-delay="0.3s">
                <div class="service-item text-center pt-3" data-bs-toggle="modal" data-bs-target="#loginModalCourses">
                    <div class="p-4">
                        <i class="fa fa-3x fa-globe text-primary mb-4"></i>
                        <h5 class="mb-3">Courses</h5>
                        <p>Skill Development: Gaining new competencies or improving existing ones.  <br>

                           Career Advancement: Enhancing qualifications or learning new technologies.<br>
                           Academic Progression: Earning credits toward a degree or certification.<br>
                           Networking Opportunities: Interacting with peers, instructors, and professionals</p>
                    </div>
                </div>
            </div>
            <!-- Service 3 -->
            <div class="col-lg-4 col-sm-4 wow fadeInUp" data-wow-delay="0.5s">
                <div class="service-item text-center pt-3" data-bs-toggle="modal" data-bs-target="#loginModaCommunication">
                    <div class="p-4">
                        <i class="fa fa-3x fa-home text-primary mb-4"></i>
                        <h5 class="mb-3">Communication</h5>
                        <p>Diam elitr kasd sed at elitr sed ipsum justo dolor sed clita am elitr kasd sed at elitr kasd sed at elitr sed ipsum juam elitr kasd sed at elitr sed ipsum juam elitr kasd sed at elitr sed ipsum juam elitr kasd sed at elitr sed ipsum juam elitr kasd sed at elitr sed ipsum juam elitr kasd sed at elitr sed ipsum juam elitr kasd sed at elitr sed ipsum juam elitr kasd sed at elitr sed ipsum juam elitr kasd sed at elitr sed ipsum juam elitr kasd sed at elitr sed ipsum juam elitr kasd sed at elitr sed ipsum ju dafafas asd as...</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="loginModaCommunication" tabindex="-1" aria-labelledby="loginModaCommunicationlable" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="loginModaCommunicationlable">Login to Proceed</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                Please log in to access this service.
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
    
<!-- Modal -->
<div class="modal fade" id="loginModaTeachersDetails" tabindex="-1" aria-labelledby="loginModaTeachersDetailsLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="loginModaTeachersDetailsLabel">Teachers Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              <div class="row g-3">
    <?php 
    include 'php/db.php';

    // Fetch teacher details along with course names
    $query = "SELECT * FROM teachers";
              
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) > 0) {
        // If there are teachers, display them
        while ($row = mysqli_fetch_assoc($result)) {
            if (empty($row['profile_image'])) {
                $row['profile_image'] = 'uploads/default-profile.png';
            }
            ?>
            <div class="col-md-4">
                <div class="card h-100 text-center">
                    <img src="<?php echo htmlspecialchars($row['profile_image']); ?>" class="card-img-top" alt="Teacher Image" style="height: 150px; object-fit: cover;">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo htmlspecialchars($row['name']); ?></h5>
                        <p class="card-text"><?php echo htmlspecialchars($row['email']); ?></p>
                        
                    </div>
                </div>
            </div>
            <?php
        }
    } else {
        // If no teachers are found, display a message
        ?>
        <div class="col-12 text-center">
            <p class="text-muted">No teachers available at the moment.</p>
        </div>
        <?php
    }
    ?>
</div>



            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>


<!-- Modal -->
<div class="modal fade" id="loginModalCourses" tabindex="-1" aria-labelledby="loginModalCoursesLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="loginModalCoursesLabel">Courses Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              <div class="row g-3">
    <?php 
    include 'php/db.php';

    // Fetch teacher details along with course names
    $query = "SELECT * FROM courses";
              
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) > 0) {
        $x =1;
        // If there are teachers, display them
        while ($row = mysqli_fetch_assoc($result)) {
            ?>
            <div class="col-md-6">
                <div class="card h-100 text-center">
                   
                    <div class="card-body">
                        <h5 class="card-title"><?php echo htmlspecialchars($row['course_name']); ?></h5>
                        <p class="card-text">Description: <?php echo htmlspecialchars($row['description']); ?></p>
                        
                    </div>
                </div>
            </div>
            <?php
            $x++;
        }
    } else {
        // If no teachers are found, display a message
        ?>
        <div class="col-12 text-center">
            <p class="text-muted">No teachers available at the moment.</p>
        </div>
        <?php
    }
    ?>
</div>



            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>


    <?php include('includes/about.php'); ?>
    <?php include('includes/notices.php'); ?>
    <?php include('includes/footer.php') ?>
</body>

</html>