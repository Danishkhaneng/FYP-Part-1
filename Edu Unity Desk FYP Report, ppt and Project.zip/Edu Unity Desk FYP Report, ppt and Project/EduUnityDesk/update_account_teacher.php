<?php
session_start();
include 'php/db.php';

if (!isset($_SESSION['teacher'])) {
    header('Location: index.php');
    exit();
}

$email = $_SESSION['teacher'];
$name = $_POST['name'];
$newEmail = $_POST['email'];
$oldPassword = $_POST['old_password'];
$newPassword = $_POST['password'];

// Fetch the current teacher data
$sql = "SELECT * FROM teachers WHERE email = '$email'";
$result = mysqli_query($conn, $sql);
$teacher = mysqli_fetch_assoc($result);

$updateFields = [];
$errors = [];

// Check if old password matches before updating
if (!empty($newPassword)) {
    if ($oldPassword == $teacher['password']) {
        $updateFields[] = "password = '$newPassword'";
    } else {
        echo "Old password is incorrect.";
        exit();
    }
}

// Check if email is unique
if ($newEmail != $email) {
    $sql = "SELECT * FROM teachers WHERE email = '$newEmail'";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0) {
        echo "Email address is already in use.";
        exit();
    } else {
        $updateFields[] = "email = '$newEmail'";
    }
}

// Handle profile image upload
if (!empty($_FILES['profile_image']['name'])) {
    // Define the target directory for image uploads
    $targetDir = "uploads/";
    $fileName = basename($_FILES["profile_image"]["name"]);
    $targetFilePath = $targetDir . $fileName;
    $fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);

    // Check if the file is a valid image
    $allowedTypes = ['jpg', 'jpeg', 'png', 'gif'];
    if (in_array($fileType, $allowedTypes)) {
        // Upload the file to the server
        if (move_uploaded_file($_FILES["profile_image"]["tmp_name"], $targetFilePath)) {
            $updateFields[] = "profile_image = '$targetFilePath'";
        } else {
            echo "Error uploading the profile image.";
            exit();
        }
    } else {
        echo "Invalid file type. Only JPG, JPEG, PNG, and GIF files are allowed.";
        exit();
    }
}

// Add name to the update fields
$updateFields[] = "name = '$name'";

// Construct the update query if there are fields to update
if (!empty($updateFields)) {
    $updateSql = "UPDATE teachers SET " . implode(', ', $updateFields) . " WHERE email = '$email'";

    if (mysqli_query($conn, $updateSql)) {
        // Update session email
        $_SESSION['teacher'] = $newEmail;
        echo 'Account information updated successfully!';
    } else {
        echo "Error updating account: " . mysqli_error($conn);
    }
} else {
    echo "No changes made.";
}

mysqli_close($conn);
?>
