<?php
session_start();
$sessionTimeout = 300; 

if (isset($_SESSION['LAST_ACTIVITY'])) {
    $lastActivity = $_SESSION['LAST_ACTIVITY'];
    $currentTime = time();
    $timeSinceLastActivity = $currentTime - $lastActivity;
    if ($timeSinceLastActivity > $sessionTimeout) {
        session_unset();
        session_destroy();
         header('Location: login.php');
    } else {
        $_SESSION['LAST_ACTIVITY'] = $currentTime;
    }
} else {
    $_SESSION['LAST_ACTIVITY'] = time();
}
$_GET['message'] = '';
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit();
}

include '../php/db.php';

// Fetch students from the database
$sql = "SELECT * FROM students";
$result = mysqli_query($conn, $sql);

// Check if the query was successful
if (!$result) {
    die("Error executing query: " . mysqli_error($conn));
}
?>



<!DOCTYPE html>
<html lang="en">

<?php include('includes/head.php') ?>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
            <?php include('includes/sidebar.php') ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

               <!-- Topbar -->
                <?php include('includes/topbar.php') ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">
                	<?php include('includes/show_message.php') ?>
                        
                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">Manage Students</h1>
                    <p class="mb-4">View and manage student details.</p>

                    <button class="btn btn-primary my-3" data-toggle="modal" data-target="#addStudentModal">Add Student</button>
                    <div class="card shadow mb-4">
                    
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>SNo.</th>
                                            <th>Image</th>
                                            <th>Name</th>
                                            <th>Reg No.</th>
						                    <th>Email</th>
						                    <th>Contact</th>
                                            <th>Status</th>
						                    <th class="actions">Actions</th>
                                        </tr>
                                    </thead>
                                    
                                    <tbody>
                                        <?php 
                                            $x = 1;
                                                 while($row = mysqli_fetch_assoc($result)) { ?>
                                            <tr>
                                                <td><?php echo $x; ?></td>
                                                <?php 
                                                if($row['profile_image']){
                                                    $profileImageStu = '../'.$row['profile_image'];
                                                }else{
                                                    $profileImageStu = '../uploads/default-profile.png';
                                                }   
                                                ?>
								                    <td><img style="width: 50px;height: 50px" src="<?php echo htmlspecialchars($profileImageStu); ?>"></td>
                                                    <td><?php echo htmlspecialchars($row['name']); ?></td>
                                                    <td><?php echo htmlspecialchars($row['reg_no']); ?></td>
								                    <td><?php echo htmlspecialchars($row['email']); ?></td>
								                    <td><?php echo htmlspecialchars($row['contact']); ?></td>
                                                    <td><?php echo htmlspecialchars($row['status']); ?></td>
								                    <td class="actions">
							                          <a class="btn btn-primary btn-sm mx-1" href="edit_student.php?id=<?php echo $row['id']; ?>">Edit</a>
                                                		<a class="btn btn-danger btn-sm mx-1" href="manage/delete_student.php?id=<?php echo $row['id']; ?>" class="delete" onclick="return confirm('Are you sure?')">Delete</a>
								                    </td>

                                            </tr>
                                            <?php 
                                            $x++;
                                        } 
                                        
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->


                <div class="modal fade" id="addStudentModal" tabindex="-1" role="dialog" 
                    aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Add Student</h5>
                                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">×</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form id="studentForm1">
                                        <div class="form-group">
                                            <label>Name</label>
                                            <input type="text" name="name" class="form-control form-control-user" id="name" aria-describedby="name"
                                                placeholder="Enter Name" required>
                                        </div> 

                                        <div class="form-group">
                                            <label>Registration Number</label>
                                            <input type="text" name="reg_no" class="form-control form-control-user" id="reg_no" aria-describedby="reg_no"
                                                placeholder="Enter Registration Number" required>
                                        </div>
                                        
                                        <div class="form-group">
                                            <label>Email</label>
                                            <input type="email" name="email" class="form-control form-control-user" id="email" aria-describedby="email"
                                                placeholder="Enter Email" required>
                                        </div>
                                        
                                        <div class="form-group">
                                            <label>Contact</label>
                                            <input type="text" name="contact" class="form-control form-control-user" id="contact" aria-describedby="contact"
                                                placeholder="Enter Contact" required>
                                        </div>

                                        <div class="form-group">
                                            <label>Password</label>
                                            <input type="password" name="password" class="form-control form-control-user" id="password"
                                                placeholder="Enter Password" required>
                                        </div>

                                        <button class="btn btn-primary" type="submit">Add</button>
                                    </form>
                            </div>  
                            <div class="modal-footer">
                                <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                            </div>
                        </div>
                    </div>
                </div>
                     <script>
                 

                    // Submit form
                    document.getElementById('studentForm1').addEventListener('submit', function(event) {
                        event.preventDefault();
                        
                        var formData = new FormData(this);
                        
                        fetch('manage/add_student.php', {
                            method: 'POST',
                            body: formData
                        })
                        .then(response => response.text())
                        .then(result => {
                                                       location.reload(); // Refresh page to show new data


                        })
                        .catch(error => console.error('Error:', error));
                    });
                </script>
 
   
            <!-- Footer -->
                       <?php include('includes/footer.php') ?>

            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->


    <?php include('includes/logoutmodal.php') ?>
    <?php include('includes/scripts.php') ?>

</body>

</html>