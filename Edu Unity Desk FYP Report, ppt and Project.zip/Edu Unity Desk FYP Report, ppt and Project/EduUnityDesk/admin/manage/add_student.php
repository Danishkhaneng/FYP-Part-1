<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: ../login.php');
    exit();
}

include '../../php/db.php'; // Make sure this path is correct

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get form inputs
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $contact = mysqli_real_escape_string($conn, $_POST['contact']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $reg_no = mysqli_real_escape_string($conn, $_POST['reg_no']);

    // Validate the input (you can add more validation)
    if (!empty($name) && !empty($email) && !empty($contact) && !empty($password)  && !empty($reg_no)) {

        // Check if the email already exists
        $checkEmail = "SELECT * FROM students WHERE email = '$email'";
        $emailResult = mysqli_query($conn, $checkEmail);

        // Check if the registration already exists
        $checkReg = "SELECT * FROM students WHERE reg_no = '$reg_no'";
        $regResult = mysqli_query($conn, $checkReg);

        if (mysqli_num_rows($emailResult) > 0) {
            $_SESSION['message'] = 'Notice: Email already exists.';
        }elseif (mysqli_num_rows($regResult) > 0) {
            $_SESSION['message'] = 'Notice: Registration Number already exists.';
        } else {
            // Hash the password before saving
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

            // Insert student into the database
            $sql = "INSERT INTO students (name, email, contact, password, reg_no , status) VALUES ('$name', '$email', '$contact', '$hashedPassword' , '$reg_no' , 'pending')";

            if (mysqli_query($conn, $sql)) {
        		$_SESSION['message'] = 'Student added successfully';
            } else {
            	$_SESSION['message'] = "Error: " . mysqli_error($conn);
            }
        }
    } else {
    	$_SESSION['message'] = 'All fields are required.';
    }
}
?>
