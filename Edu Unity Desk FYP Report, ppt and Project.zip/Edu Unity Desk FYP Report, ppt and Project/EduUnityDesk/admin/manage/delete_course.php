<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: ../login.php');
    exit();
}

include '../../php/db.php'; // Ensure the correct path

// Get the course ID from the URL
$id = $_GET['id'];

// Prepare and execute the delete query
$sql = "DELETE FROM courses WHERE id = $id";
$sql1 = "DELETE FROM course_file WHERE course_id = $id";
$sql2 = "DELETE FROM course_chat WHERE course_id = $id";
$sql3 = "DELETE FROM saved_courses WHERE course_id = $id";

mysqli_query($conn, $sql1);
      
mysqli_query($conn, $sql2);
mysqli_query($conn, $sql3);


mysqli_query($conn, $sql);
         session_start();

        $_SESSION['message'] = 'Record Deleted';
        header('Location: ../manage_courses.php');
        exit();

?>
