<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: index.php');
    exit();
}

include '../../php/db.php';

// Get ID from the URL
if (!isset($_GET['id'])) {
    die("No ID provided");
}

$id = $_GET['id'];

// Prepare SQL statement to delete the record
$sql = "DELETE FROM admin WHERE id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, 'i', $id);

if (mysqli_stmt_execute($stmt)) {
        $_SESSION['message'] = 'Record Deleted';
        header('Location: ../manage_coordinators.php');
} else {
    die("Error deleting record: " . mysqli_error($conn));
}

mysqli_stmt_close($stmt);
mysqli_close($conn);
?>
