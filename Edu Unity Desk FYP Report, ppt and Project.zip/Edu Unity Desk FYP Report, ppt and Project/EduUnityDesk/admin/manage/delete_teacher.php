<?php
include '../../php/db.php'; // Adjust this path if necessary

if (isset($_GET['id'])) {
    $teacher_id = intval($_GET['id']);

    // Delete the teacher record from the database
    $sql = "DELETE FROM teachers WHERE id = $teacher_id";

    if (mysqli_query($conn, $sql)) {
         session_start();
        $_SESSION['message'] = 'Record Deleted';
        header('Location: ../manage_teachers.php');
        exit();
    } else {
        die("Error deleting record: " . mysqli_error($conn));
    }
} else {
    // Redirect if no ID is provided
    header('Location: manage_teachers.php');
    exit();
}
?>
