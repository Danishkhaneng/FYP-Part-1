<?php
session_start();
include '../../php/db.php';

if (!isset($_SESSION['admin'])) {
    header('Location: ../login.php');
    exit();
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $sql = "DELETE FROM notices WHERE id = $id";
    if (mysqli_query($conn, $sql)) {
        $_SESSION['message'] = 'Record Deleted';
        header("Location: ../manage_notices.php");
    } else {
        echo "Error deleting notice: " . mysqli_error($conn);
    }
}

mysqli_close($conn);
?>
