<?php
include '../../php/db.php'; // Ensure this path is correct

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve data from POST request
    $course_name = mysqli_real_escape_string($conn, $_POST['course_name']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);

    // Check if course name already exists
    $check_query = "SELECT id FROM courses WHERE course_name = '$course_name'";
    $check_result = mysqli_query($conn, $check_query);

    if (mysqli_num_rows($check_result) > 0) {
        session_start();
        $_SESSION['message'] = "Course name already exists. Please choose a different name.";
    } else {
        // Insert data into database
        $sql = "INSERT INTO courses (course_name, description) VALUES ('$course_name', '$description')";
        if (mysqli_query($conn, $sql)) {
            session_start();
            $_SESSION['message'] = "Course added successfully.";
        } else {
            echo "Error adding course: " . mysqli_error($conn);
        }
    }
}
?>
