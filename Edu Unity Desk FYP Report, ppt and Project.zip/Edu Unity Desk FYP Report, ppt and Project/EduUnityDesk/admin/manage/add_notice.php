<?php
session_start();
include '../../php/db.php';

if (!isset($_SESSION['admin'])) {
    header('Location: ../login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $content = $_POST['content'];
    $date = $_POST['date'];

    // Handle image upload
    if ($_FILES['image']['name']) {
        $target_dir = "../../uploads/";

        // Generate a unique name for the image
        $image = uniqid() . "_" . basename($_FILES['image']['name']);
        $target_file = $target_dir . $image;

        // Upload the image
        if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
            $image_url = "uploads/" . $image; // Store the relative path in the database
            $sql = "INSERT INTO notices (title, content, date, image) VALUES ('$title', '$content', '$date', '$image_url')";
        } else {
        	$_SESSION['message'] = 'Error uploading image.';
            exit();
        }
    } else {
        // If no image is uploaded, insert without the image field
        $sql = "INSERT INTO notices (title, content, date) VALUES ('$title', '$content', '$date')";
    }

    // Execute query and check for errors
    if (mysqli_query($conn, $sql)) {
    	        	$_SESSION['message'] = 'Notice added successfully.';

    } else {
        echo "Error: " . mysqli_error($conn);
    }
}

mysqli_close($conn);
?>
