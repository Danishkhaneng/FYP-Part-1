<?php
include '../../php/db.php'; // Make sure this path is correct

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve data from POST request
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $contact = mysqli_real_escape_string($conn, $_POST['contact']);
    $experience = mysqli_real_escape_string($conn, $_POST['experience']);
    $course_id = mysqli_real_escape_string($conn, $_POST['course_id']);

    // Check if the email already exists
        $checkEmail = "SELECT * FROM teachers WHERE email = '$email'";
        $emailResult = mysqli_query($conn, $checkEmail);

        if (mysqli_num_rows($emailResult) > 0) {
           session_start();
            $_SESSION['message'] = 'Notice: Email already exists.';
             header('Location: manage_teachers.php');
                exit;
        }

    // Insert data into database
    $sql = "INSERT INTO teachers (email, password, name, contact, experience, course_id) VALUES ('$email','$password','$name', '$contact', '$experience', '$course_id')";
    if (mysqli_query($conn, $sql)) {
        session_start();
        $_SESSION['message'] = 'Teacher added successfully.';
    } else {
        echo "Error adding teacher: " . mysqli_error($conn);
    }
}
?>
