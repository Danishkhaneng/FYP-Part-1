<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: ../login.php');
    exit();
}

include '../../php/db.php'; // Make sure this path is correct

// Get the student ID from the URL
$id = $_GET['id'];

// Delete related records from the communication table
$sql_communication = "DELETE FROM communication WHERE student_id = $id";
mysqli_query($conn, $sql_communication);

// Delete related records from the saved_courses table
$sql_saved_courses = "DELETE FROM saved_courses WHERE student_id = $id";
mysqli_query($conn, $sql_saved_courses);

// Now delete the student from the students table
$sql_student = "DELETE FROM students WHERE id = $id";
if (mysqli_query($conn, $sql_student)) {
    $_SESSION['message'] = 'Record deleted successfully';
    header("Location: ../manage_students.php");
} else {
    $_SESSION['message'] = "Error deleting record: " . mysqli_error($conn);
}

?>
