<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: ../login.php');
    exit();
}

include '../../php/db.php';

// Get student_id and course_id from the URL
$student_id = $_GET['student_id'];
$course_id = $_GET['course_id'];

// Validate inputs
if (empty($student_id) || empty($course_id)) {
    die("Invalid input");
}

// Prepare SQL statement to delete the record
$sql = "DELETE FROM saved_courses WHERE student_id = ? AND course_id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, 'ii', $student_id, $course_id);

// Execute the statement
if (mysqli_stmt_execute($stmt)) {
	session_start();
    $_SESSION['message'] = 'Course successfully removed';
    header("Location: ../manage_saved_courses.php");
} else {
    // Output error if the query failed
    die("Error deleting record: " . mysqli_error($conn));
}

// Close connection
mysqli_stmt_close($stmt);
mysqli_close($conn);
?>
