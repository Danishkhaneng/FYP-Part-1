<?php
session_start();
$sessionTimeout = 300; 

if (isset($_SESSION['LAST_ACTIVITY'])) {
    $lastActivity = $_SESSION['LAST_ACTIVITY'];
    $currentTime = time();
    $timeSinceLastActivity = $currentTime - $lastActivity;
    if ($timeSinceLastActivity > $sessionTimeout) {
        session_unset();
        session_destroy();
         header('Location: login.php');
    } else {
        $_SESSION['LAST_ACTIVITY'] = $currentTime;
    }
} else {
    $_SESSION['LAST_ACTIVITY'] = time();
}
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit();
}

include '../php/db.php'; // Ensure the correct path

// Get the student ID from the URL
$id = $_GET['id'];

// Fetch the student data
$sql = "SELECT * FROM students WHERE id = $id";
$result = mysqli_query($conn, $sql);
$student = mysqli_fetch_assoc($result);

// Update the student if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $contact = mysqli_real_escape_string($conn, $_POST['contact']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $reg_no = mysqli_real_escape_string($conn, $_POST['reg_no']);
    $status = mysqli_real_escape_string($conn, $_POST['status']);

    // Check if the email already exists for another student
    $email_check_sql = "SELECT * FROM students WHERE email = '$email' AND id != '$id'";
    $email_check_result = mysqli_query($conn, $email_check_sql);

    // Check if the email already exists for another student
    $reg_no_check_sql = "SELECT * FROM students WHERE reg_no = '$reg_no' AND id != '$id'";
    $reg_no_check_result = mysqli_query($conn, $reg_no_check_sql);

    if (mysqli_num_rows($email_check_result) > 0) {
    	$_SESSION['message'] = 'Notice: Email already exists.';
    }elseif (mysqli_num_rows($reg_no_check_result) > 0) {
        $_SESSION['message'] = 'Notice: Registration Number already exists.';
    } else {
        // Prepare the SQL query
        if (!empty($password)) {
            // Hash the password before updating
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            $update_sql = "UPDATE students SET name='$name', email='$email', contact='$contact', password='$hashedPassword', status= '$status', reg_no='$reg_no' WHERE id = '$id'";
        } else {
            // Update without changing the password if it's left empty
            $update_sql = "UPDATE students SET name='$name', email='$email', contact='$contact', status= '$status', reg_no='$reg_no' WHERE id = '$id'";
        }

        if (mysqli_query($conn, $update_sql)) {
        
             $_SESSION['message'] = 'Student Updated Successfully';
            header('Location: edit_student.php?id='.$id.'');
            exit();
        } else {
            echo "Error updating record: " . mysqli_error($conn);
        }
    }
}
?>


<!DOCTYPE html>
<html lang="en">

<?php include('includes/head.php') ?>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
            <?php include('includes/sidebar.php') ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

               <!-- Topbar -->
                <?php include('includes/topbar.php') ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">
                     <?php include('includes/show_message.php') ?>
                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">Edit Student</h1>
                    <p class="mb-4">Update the details of the studentt.</p>
                    <?php 
                    if ($student['profile_image']) {
                        $profileImgstu = '../'.$student['profile_image'];
                    }else{
                        $profileImgstu = '../uploads/default-profile.png';
                    }
                    ?>
                      <div class=" py-2">
                               <img src="<?php echo htmlspecialchars($profileImgstu); ?>" style="width: 100px;height: auto;">
                            </div>

                         <form action="edit_student.php?id=<?php echo $student['id']; ?>" method="POST">
                            
                            <div class="form-group py-2">
                                <label>Name</label>
                                <input type="text" name="name" class="form-control form-control-user" id="name" aria-describedby="name"
                                   value="<?php echo htmlspecialchars($student['name']); ?>"  required>
                            </div> 

                            <div class="form-group py-2">
                                <label>Registration Number</label>
                                <input type="text" name="reg_no" class="form-control form-control-user" id="reg_no" aria-describedby="reg_no"
                                   value="<?php echo htmlspecialchars($student['reg_no']); ?>"  required>
                            </div>
                            
                            <div class="form-group py-2">
                                 <label>Email</label>
                                <input type="email" name="email" class="form-control form-control-user" id="email" aria-describedby="email"
                                   value="<?php echo htmlspecialchars($student['email']); ?>"  required>
                            </div>
                            
                            <div class="form-group py-2">
                                <label>Contact</label>
                                <input type="text" name="contact" class="form-control form-control-user" id="contact" aria-describedby="contact"
                                   value="<?php echo htmlspecialchars($student['contact']); ?>" required>
                            </div>

                            <div class="form-group py-2">
                                <label>Password</label>
                            	<label for="password">Password (Leave blank to keep current password):</label>
                                <input type="password" name="password" class="form-control form-control-user" id="password">
                            </div>

                             <div class="form-group">

                                <label>Status</label>
                                 <select id="status" name="status" class="form-control form-control-user" required>
                                    <option value="pending" <?php echo $student['status'] == 'pending' ? 'selected' : ''; ?>>Pending</option>
                                    <option value="approved" <?php echo $student['status'] == 'approved' ? 'selected' : ''; ?>>Approved</option>
                                </select>
                              
                            </div>
                           
                            <button type="submit" class="btn btn-primary">Update</button>
                        </form>

                <a class="btn btn-danger my-4" href="manage_students.php">Back</a>

                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
                       <?php include('includes/footer.php') ?>

            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->


    <?php include('includes/logoutmodal.php') ?>
    <?php include('includes/scripts.php') ?>

</body>

</html>