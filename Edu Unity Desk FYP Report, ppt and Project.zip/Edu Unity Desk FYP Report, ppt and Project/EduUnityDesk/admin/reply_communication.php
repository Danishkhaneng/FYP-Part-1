<?php
session_start();
$sessionTimeout = 300; 

if (isset($_SESSION['LAST_ACTIVITY'])) {
    $lastActivity = $_SESSION['LAST_ACTIVITY'];
    $currentTime = time();
    $timeSinceLastActivity = $currentTime - $lastActivity;
    if ($timeSinceLastActivity > $sessionTimeout) {
        session_unset();
        session_destroy();
         header('Location: login.php');
    } else {
        $_SESSION['LAST_ACTIVITY'] = $currentTime;
    }
} else {
    $_SESSION['LAST_ACTIVITY'] = time();
}
if (!isset($_SESSION['admin'])) {
    header('Location: index.php');
    exit();
}

include '../php/db.php';

// Get the communication ID and reply from the form
$communication_id = isset($_POST['communication_id']) ? intval($_POST['communication_id']) : 0;
$reply = isset($_POST['reply']) ? mysqli_real_escape_string($conn, $_POST['reply']) : '';
$newStatusResolved = isset($_POST['status']) ? mysqli_real_escape_string($conn, $_POST['status']) : '';

// Fetch the current feedback
$sql = "SELECT * FROM communication WHERE id = $communication_id";
$result = mysqli_query($conn, $sql);
$communication = mysqli_fetch_assoc($result);
$feedback = json_decode($communication['feedback'], true) ?: [];
$statusCheck = $communication['status'];

$statusCheckNew = 'Waiting For Student Response';

if ($newStatusResolved == 'Resolved') {
    $statusCheckNew = 'Resolved';
}

// Add the new reply to the feedback
$feedback[] = [
    'role' => 'admin',
    'message' => $reply,
    'timestamp' => date('Y-m-d H:i:s')
];

// Update the communication with the new feedback
$feedback_json = json_encode($feedback);
$sql = "UPDATE communication SET feedback = '$feedback_json', status = '$statusCheckNew' WHERE id = $communication_id";
if (mysqli_query($conn, $sql)) {
	  $_SESSION['message'] = 'Reply sent successfully.';
      header('Location: view_communication.php?id='.$communication_id.'');
} else {
    echo "Error: " . mysqli_error($conn);
}

mysqli_close($conn);
?>
