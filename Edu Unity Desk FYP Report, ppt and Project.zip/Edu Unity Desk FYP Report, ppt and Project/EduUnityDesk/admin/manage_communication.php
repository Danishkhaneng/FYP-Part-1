<?php
session_start();
$sessionTimeout = 300; 

if (isset($_SESSION['LAST_ACTIVITY'])) {
    $lastActivity = $_SESSION['LAST_ACTIVITY'];
    $currentTime = time();
    $timeSinceLastActivity = $currentTime - $lastActivity;
    if ($timeSinceLastActivity > $sessionTimeout) {
        session_unset();
        session_destroy();
         header('Location: login.php');
    } else {
        $_SESSION['LAST_ACTIVITY'] = $currentTime;
    }
} else {
    $_SESSION['LAST_ACTIVITY'] = time();
}
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit();
}

include '../php/db.php';

// Fetch communications from the database
$sql = "SELECT c.*, s.name AS student_name, s.reg_no AS reg_no FROM communication c JOIN students s ON c.student_id = s.id";
$result = mysqli_query($conn, $sql);

// Check if the query was successful
if (!$result) {
    die("Error executing query: " . mysqli_error($conn));
}

// Fetch all students for the form
$studentsResult = mysqli_query($conn, "SELECT id, name FROM students");
$students = mysqli_fetch_all($studentsResult, MYSQLI_ASSOC);

?>



<!DOCTYPE html>
<html lang="en">

<?php include('includes/head.php') ?>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
            <?php include('includes/sidebar.php') ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

               <!-- Topbar -->
                <?php include('includes/topbar.php') ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <?php include('includes/show_message.php') ?>

                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">Manage Queries</h1>
                    <p class="mb-4">View and manage quries details.</p>
                  
                    <div class="card shadow mb-4">
                    
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>SNo.</th>
                                            <th>Student</th>
						                    <th>Voucher Number</th>
                                            <th>Category</th>
                                            <th>Coordinator</th>
                                            <th>Status</th>
						                    <th class="actions">Actions</th>
                                        </tr>
                                    </thead>
                                    
                                    <tbody>
                                        <?php 
                                            $x = 1;
                                            while($row = mysqli_fetch_assoc($result)) { ?>
                                            <tr>
                                                <td><?php echo $x; ?></td>
							                    <td><?php echo htmlspecialchars($row['student_name']); ?>
                                                <small class="text-danger">(<?php echo htmlspecialchars($row['reg_no']); ?>)</small>
                                                </td>
							                    <td><?php echo htmlspecialchars($row['voucher_number']); ?></td>
                                                <td><?php
                                                        if ($row['q_category'] == 'student_services') {
                                                           echo 'Student Services';
                                                        }elseif ($row['q_category'] == 'admission_department') {
                                                            echo 'Admission Department';
                                                        }elseif ($row['q_category'] == 'fees_department') {
                                                            echo 'Fees Department';
                                                        }

                                                        ?>
                                                </td>
                                                <td><?php echo htmlspecialchars($row['q_coordinator']); ?></td>
                                                 <td><?php echo htmlspecialchars($row['status']); ?>

							                    <td class="actions">
							                        <a class="btn btn-primary btn-sm mx-1" href="view_communication.php?id=<?php echo $row['id']; ?>">Reply</a>
							                    </td>
                                              
                                            </tr>
                                            <?php 
                                            $x++;
                                        } 
                                         
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->


            <!-- Footer -->
                       <?php include('includes/footer.php') ?>

            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->


    <?php include('includes/logoutmodal.php') ?>
    <?php include('includes/scripts.php') ?>

</body>

</html>