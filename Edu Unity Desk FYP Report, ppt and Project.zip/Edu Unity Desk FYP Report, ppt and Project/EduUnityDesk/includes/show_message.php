<?php if (isset($_SESSION['message']) && !empty($_SESSION['message'])): ?>
                            <div id="messagesShow">
                                 <p class="bg-warning text-dark text-center text-bold my-3 p-3"><?php echo htmlspecialchars($_SESSION['message']); ?></p>
                            </div>
                        <?php
                        $_SESSION['message'] = ''; 
                    endif; ?>