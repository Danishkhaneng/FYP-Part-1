<!DOCTYPE html>
<html lang="en">

<?php include('includes/head.php') ?>
<?php
if (!isset($_SESSION['student'])) {
    header('Location: index.php');
    exit();
}

include 'php/db.php';

// Fetch student information
$email = $_SESSION['student'];
$sql = "SELECT * FROM students WHERE email = '$email'";
$result = mysqli_query($conn, $sql);
$student = mysqli_fetch_assoc($result);
?>

<body>
    <?php include('includes/spinner.php') ?>
    <?php include('includes/navbar.php') ?>
    <?php include('includes/show_message.php') ?>


  <div class="container mt-5">
    <h1>Welcome to Student Dashboard, <?php echo htmlspecialchars($student['name']); ?></h1>

    <!-- Card Row -->

    <div class="row my-3 pt-5">
        <!-- Card for My Account -->
        <div class="col-md-4">
            <div class="card dashboard-cards-all text-center">
                <div class="card-icon mt-3">
                    <i class="fa fa-user-circle fa-3x text-primary"></i>
                </div>
                <div class="card-body">
                    <h5 class="card-title">My Account</h5>
                    <p class="card-text">View and update your account information.</p>
                    <!-- Button to open My Account modal -->
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#myAccountModal">View Account</button>
                </div>
            </div>
        </div>

       <!-- Card for Courses -->
       <div class="col-md-4">
            <div class="card dashboard-cards-all text-center">
                <div class="card-icon mt-3">
                    <i class="fa fa-user-circle fa-3x text-primary"></i>
                </div>
                <div class="card-body">
                    <h5 class="card-title">All Courses</h5>
                    <p class="card-text">View and manage your courses.</p>
                    <button class="btn btn-primary" id="openCoursesPopupBtn" data-bs-toggle="modal" data-bs-target="#coursesModal">View All Courses</button>
                </div>
            </div>
        </div>
        <!-- Card for Favourite Courses -->
        <div class="col-md-4">
            <div class="card dashboard-cards-all text-center">
                <div class="card-icon mt-3">
                    <i class="fa fa-star fa-3x text-primary"></i>
                </div>
                <div class="card-body">
                    <h5 class="card-title">Saved Courses</h5>
                    <p class="card-text">View your favourite courses.</p>
                    <button class="btn btn-primary" id="openFavCoursesPopupBtn" data-bs-toggle="modal" data-bs-target="#coursesFavModal">View Course Details / Communication</button>
                </div>
            </div>
        </div>
    </div>
    <div class="row mb-5 pb-5">
        <div class="col-md-4">
            <div class="card dashboard-cards-all text-center">
                <div class="card-icon mt-3">
                    <i class="fa fa-star fa-3x text-primary"></i>
                </div>
                <div class="card-body">
                    <h5 class="card-title">Queries</h5>
                    <p class="card-text">Ask Query.</p>
                    <a href="ask_query.php" class="btn btn-primary" >View</a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- My Account Modal -->
<div class="modal fade" id="myAccountModal" tabindex="-1" aria-labelledby="myAccountModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="myAccountModalLabel">My Account</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <!-- Account information form or content goes here -->
                <form id="accountForm" method="POST" action="update_account.php">


                    <!-- Display the current profile image if available -->
                    <div class="mb-3">
                        <?php if (!empty($student['profile_image'])): ?>
                            <img src="<?php echo htmlspecialchars($student['profile_image']); ?>" alt="Profile Image" class="img-thumbnail" width="150">
                        <?php else: ?>
                           <img src="uploads/default-profile.png" alt="Profile Image" class="img-thumbnail" width="150">
                        <?php endif; ?>
                    </div>

                     <!-- Other form fields remain the same -->
                     <div class="mb-3">
                        <label for="profile_image" class="form-label">Profile Image</label>

                        <?php if (!empty($student['profile_image'])): ?>
                           <input type="file" name="profile_image" value="<?php echo htmlspecialchars($student['profile_image']); ?>" class="form-control" id="profile_image">
                        <?php else: ?>
                          <input type="file" name="profile_image" value="uploads/default-profile.png"  class="form-control" id="profile_image">
                        <?php endif; ?>
                    </div>

    

                    <div class="mb-3">
                        <label for="name" class="form-label">Name</label>
                        <input type="text" name="name" class="form-control" id="name" value="<?php echo htmlspecialchars($student['name']); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" name="email" class="form-control" id="email" value="<?php echo htmlspecialchars($student['email']); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="contact" class="form-label">Contact</label>
                        <input type="text" name="contact" class="form-control" id="contact" value="<?php echo htmlspecialchars($student['contact']); ?>">
                    </div>

                    <div class="mb-3">
                        <label for="old_password" class="form-label">Old Password</label>
                        <input type="password" id="old_password" name="old_password" class="form-control" id="old_password">
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">New Password</label>
                        <input type="password" class="form-control" name="password" id="password">
                    </div>
                   <button type="submit" class="btn btn-primary">Save Changes</button>

                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>



<!-- Courses Modal -->

<div class="modal fade" id="coursesModal" tabindex="-1" aria-labelledby="coursesModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="coursesModalLabel">Courses</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <table class="table table-striped" id="coursesTable">
                  <thead>
                    <tr>
                      <th>Course</th>
                      <th>Teacher</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <!-- Dynamic rows will be inserted here -->
                  </tbody>
                </table>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- Fav Courses Modal -->

<div class="modal fade" id="coursesFavModal" tabindex="-1" aria-labelledby="coursesFavModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="coursesFavModalLabel">Favourite Courses</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
             
                 <table id="favCoursesTable" class="table table-striped table-hover">
                    <thead class="thead-dark">
                        <tr>
                            <th>Course</th>
                            <th>Teacher</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- Rows will be dynamically inserted here -->
                    </tbody>
                </table>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>






<!-- Custom Popup HTML -->
<div id="customAlert" style="display: none;">
    <div id="customAlertContent">
        <p id="alertMessage"></p>
        <button id="reloadButton">Reload</button>
    </div>
</div>

<!-- Custom Popup CSS -->
<style>
    #customAlert {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 99999999999999999999999;
    }

    #customAlertContent {
        background-color: white;
        padding: 20px;
        border-radius: 10px;
        text-align: center;
    }

    #reloadButton {
        margin-top: 10px;
        padding: 10px 20px;
        background-color: #007bff;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }

    #reloadButton:hover {
        background-color: #0056b3;
    }
</style>


<script>
       

        // Open popup for courses
            document.getElementById('openCoursesPopupBtn').addEventListener('click', function() {
                fetch('fetch_courses.php')
                    .then(response => response.json())
                    .then(courses => {
                        console.log(courses)
                        const tbody = document.querySelector('#coursesTable tbody');
                        tbody.innerHTML = ''; // Clear existing rows

                        courses.forEach(course => {
                            const tr = document.createElement('tr');
                            tr.innerHTML = `
                                <td>${course.course_name}</td>
                                <td>${course.teacher_name}</td>
                                <td><button class="btn btn-primary btn-sm add-fav-btn" data-teacher="${course.teacher_id}" data-course="${course.id}">Add to Favourite</button></td>
                            `;
                            tbody.appendChild(tr);
                        });

                    })
                    .catch(error => console.error('Error fetching courses:', error));
            });

       // Open popup for favourite courses and load data
        document.getElementById('openFavCoursesPopupBtn').addEventListener('click', function() {
            fetch('fetch_fav_courses.php')
                .then(response => response.json())
                .then(favCourses => {
                    const tbody = document.querySelector('#favCoursesTable tbody');
                    tbody.innerHTML = ''; // Clear existing rows

                    favCourses.forEach(course => {
                        const tr = document.createElement('tr');
                        tr.innerHTML = `
                            <td>${course.course_name}</td>
                            <td>${course.teacher_name}</td>
                            <td>

                            <a href="student_course.php?course_id=${course.course_view_id}&teacher_id=${course.teacher_view_id}" class="btn btn-warning btn-sm" >View/Chat</a>
                                <button class="btn btn-danger btn-sm remove-fav-btn" data-course="${course.id}">Remove</button>
                            </td>
                            
                        `;
                        tbody.appendChild(tr);
                    });

                    document.getElementById('favCoursesPopup').style.display = 'flex';
                })
                .catch(error => console.error('Error fetching favourite courses:', error));
        });

        // Close popup
        document.querySelectorAll('.popup-close').forEach(btn => {
            btn.addEventListener('click', function() {
                this.parentElement.parentElement.style.display = 'none';
            });
        });

        // AJAX form submission
        document.getElementById('accountForm').addEventListener('submit', function(event) {
            event.preventDefault();

            var formData = new FormData(this);

            fetch('update_account.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.text())
            .then(result => {
                 // Set the custom alert message
        document.getElementById('alertMessage').textContent = result + " Reload to see changes.";
        
        // Display the custom alert
        document.getElementById('customAlert').style.display = 'flex';

        // Add event listener to the reload button to redirect to student_dashboard.php
        document.getElementById('reloadButton').addEventListener('click', function() {
            window.location.href = 'student_dashboard.php';
        });
            })
            .catch(error => console.error('Error:', error));
        });

        document.addEventListener('click', function(event) {
            if (event.target.classList.contains('add-fav-btn')) {
                const courseId = event.target.getAttribute('data-course');
                const teacherId = event.target.getAttribute('data-teacher');
                
                fetch('add_to_favourites.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    body: `course_id=${courseId}&teacher_id=${teacherId}`
                })
                .then(response => response.text())
                .then(result => {
                    alert(result); // Show success or failure message
                })
                .catch(error => console.error('Error adding to favourites:', error));
            }
        });

        document.addEventListener('click', function(event) {
            if (event.target.classList.contains('remove-fav-btn')) {
                const courseId = event.target.getAttribute('data-course');
                
                // Send a request to remove the course from favourites
                fetch('remove_from_favourites.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    body: `course_id=${courseId}`
                })
                .then(response => response.text())
                .then(result => {
                    alert(result); // Show success or failure message
                    
                    // Optionally remove the row from the table after deletion
                    if (result.includes('successfully')) {
                        event.target.closest('tr').remove();
                    }
                })
                .catch(error => console.error('Error removing from favourites:', error));
            }
        });

    </script>

    <?php include('includes/footer.php') ?>
</body>

</html>