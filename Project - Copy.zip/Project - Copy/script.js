// Toggle Navbar
let navbar = document.querySelector('.header .navbar');
document.querySelector('#menu-btn').addEventListener('click', () => {
    navbar.classList.add('active');
});

document.querySelector('#close-navbar').addEventListener('click', () => {
    navbar.classList.remove('active');
});

// Toggle Account Form
let registerBtn = document.querySelector('.account-form .register-btn');
let loginBtn = document.querySelector('.account-form .login-btn');

registerBtn.addEventListener('click', () => {
    registerBtn.classList.add('active');
    loginBtn.classList.remove('active');
    document.querySelector('.account-form .login-form').classList.remove('active');
    document.querySelector('.account-form .register-form').classList.add('active');
});

loginBtn.addEventListener('click', () => {
    registerBtn.classList.remove('active');
    loginBtn.classList.add('active');
    document.querySelector('.account-form .login-form').classList.add('active');
    document.querySelector('.account-form .register-form').classList.remove('active');
});

let accountForm = document.querySelector('.account-form');

document.querySelector('#account-btn').addEventListener('click', () => {
    accountForm.classList.add('active');
});

document.querySelector('#close-form').addEventListener('click', () => {
    accountForm.classList.remove('active');
});

// Swiper Sliders
var swiper = new Swiper(".home-slider", {
    pagination: {
      el: ".swiper-pagination",
      clickable: true,
    },
    loop: true,
    grabCursor: true,
});

var homeCoursesSwiper = new Swiper(".home-courses-slider", {
    loop: true,
    grabCursor: true,
    spaceBetween: 20,
    breakpoints: {
        0: {
            slidesPerView: 1,
        },
        768: {
            slidesPerView: 2,
        },
        991: {
            slidesPerView: 3,
        },
    },
});



var teachersSwiper = new Swiper(".teachers-slider", {
    loop: true,
    grabCursor: true,
    spaceBetween: 20,
    breakpoints: {
        0: {
            slidesPerView: 1,
        },
        768: {
            slidesPerView: 2,
        },
        991: {
            slidesPerView: 3,
        },
    },
});

var reviewsSwiper = new Swiper(".reviews-slider", {
    loop: true,
    grabCursor: true,
    spaceBetween: 20,
    breakpoints: {
        0: {
            slidesPerView: 1,
        },
        768: {
            slidesPerView: 2,
        },
        991: {
            slidesPerView: 3,
        },
    },
});

var logoSwiper = new Swiper(".logo-slider", {
    loop: true,
    grabCursor: true,
    spaceBetween: 20,
    breakpoints: {
        0: {
            slidesPerView: 1,
        },
        450: {
            slidesPerView: 2,
        },
        768: {
            slidesPerView: 3,
        },
        991: {
            slidesPerView: 4,
        },
        1200: {
            slidesPerView: 5,
        },
    },
});

// FAQ Accordion
let accordionItems = document.querySelectorAll('.faq .accordion-container .accordion');

accordionItems.forEach(item => {
    item.addEventListener('click', () => {
        accordionItems.forEach(acc => acc.classList.remove('active'));
        item.classList.toggle('active');
    });
});

// Load More Courses
document.querySelector('.load-more .btn').addEventListener('click', () => {
    document.querySelectorAll('.courses .box-container .hide').forEach(show => {
        show.style.display = 'block';
    });
    document.querySelector('.load-more .btn').style.display = 'none';
});
