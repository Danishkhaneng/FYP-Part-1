/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./home.html ./about.html ./style.css ./input.css ./script.js'],
  theme: {
    extend: {},
  },
  plugins: [],
}

