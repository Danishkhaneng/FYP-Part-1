
<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "doctor_appointment_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $appointment_date = $_POST['appointment_date'];
    $phone_number = $_POST['phone_number'];
    $sickness = $_POST['sickness'];

    // Input validation
    if (!empty($name) && !empty($email) && !empty($appointment_date) && !empty($phone_number) && !empty($sickness)) {
        $stmt = $conn->prepare("INSERT INTO appointments (name, email, appointment_date, phone_number, sickness) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $name, $email, $appointment_date, $phone_number, $sickness);

        if ($stmt->execute()) {
            echo "Appointment successfully booked!";
        } else {
            echo "Error: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Please fill in all required fields.";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Doctor Appointment Form</title>
</head>
<body>
    <h2>Book a Doctor's Appointment</h2>
    <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <label for="name">Name:</label><br>
        <input type="text" id="name" name="name" required><br><br>

        <label for="email">Email:</label><br>
        <input type="email" id="email" name="email" required><br><br>

        <label for="appointment_date">Appointment Date:</label><br>
        <input type="date" id="appointment_date" name="appointment_date" required><br><br>

        <label for="phone_number">Phone Number:</label><br>
        <input type="text" id="phone_number" name="phone_number" required><br><br>

        <label for="sickness">Sickness:</label><br>
        <textarea id="sickness" name="sickness" required></textarea><br><br>

        <input type="submit" value="Submit">
    </form>
</body>
</html>
