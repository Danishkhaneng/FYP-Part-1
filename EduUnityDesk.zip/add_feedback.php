<?php
session_start();
include 'php/db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $query_id = $_POST['query_id'];
    $feedback_message = mysqli_real_escape_string($conn, $_POST['feedback']);
    
    // Fetch the existing query details
    $sqlQuery = "SELECT * FROM communication WHERE id = '$query_id'";
    $resultQuery = mysqli_query($conn, $sqlQuery);
    $queryDetails = mysqli_fetch_assoc($resultQuery);

    // Decode the existing feedback
    $feedback = json_decode($queryDetails['feedback'], true);
    
    // Add new feedback
    $feedback[] = [
        'role' => 'student', // Update this as needed based on the user role
        'message' => $feedback_message,
        'timestamp' => date('Y-m-d H:i:s')
    ];
    
    // Update the feedback in the database
    $feedback_json = json_encode($feedback);
    $sqlUpdate = "UPDATE communication SET feedback = '$feedback_json' , status = 'Waiting For Coordinator Response' WHERE id = '$query_id'";

    if (mysqli_query($conn, $sqlUpdate)) {
        $_SESSION['message'] = 'Feedback submitted successfully!';
        header('Location: view_query.php?id=' . $query_id); // Redirect to the query view page
        exit();
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}

mysqli_close($conn);
?>
