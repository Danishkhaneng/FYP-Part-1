<?php
session_start();
include 'php/db.php';

header('Content-Type: application/json');

// Fetch courses information
$email = $_SESSION['student'];
$sql = "
    SELECT c.id, c.course_name, c.description, t.name AS teacher_name, t.id AS teacher_id
    FROM courses c
    JOIN teachers t ON c.id = t.course_id
";

$result = mysqli_query($conn, $sql);

if (!$result) {
    echo json_encode(['error' => 'Database query failed']);
    exit();
}

$courses = [];
while ($row = mysqli_fetch_assoc($result)) {
    $courses[] = $row;
}

echo json_encode($courses);
?>
