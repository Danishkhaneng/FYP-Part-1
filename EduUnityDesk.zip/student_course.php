<!DOCTYPE html>
<html lang="en">

<?php include('includes/head.php') ?>
<?php
if (!isset($_SESSION['student'])) {
    header('Location: index.php');
    exit();
}

include 'php/db.php';

// Fetch student information
$emailStudent = $_SESSION['student'];
$sqlstu = "SELECT * FROM students WHERE email = '$emailStudent'";
$resultstu = mysqli_query($conn, $sqlstu);
$studentcurt = mysqli_fetch_assoc($resultstu);

if (!empty($_GET['course_id']) &&  !empty($_GET['teacher_id'])) {
	$course_id = $_GET['course_id'];
	$teacher_id = $_GET['teacher_id'];
	$course_name_sql = "SELECT course_name FROM courses WHERE id = $course_id";
	$course_name_result = mysqli_query($conn, $course_name_sql);
	$course_name_row = mysqli_fetch_assoc($course_name_result);

		// Fetch chat messages for the course
	$sql1212 = "SELECT * FROM course_chat WHERE course_id = '$course_id' AND teacher_id = '$teacher_id' ORDER BY id ASC";
	$resultChat = mysqli_query($conn, $sql1212);

}else{
	 header('Location: student_dashboard.php');
	 exit();
}

                                            
?>

<body>
    <?php include('includes/spinner.php') ?>
    <?php include('includes/navbar.php') ?>
    <?php include('includes/show_message.php') ?>

   <!-- Add Courses Tables Here -->
   <div class="container my-3 py-3">
  
   	<?php
   	if (isset($course_name_row['course_name'])) {
   		?>
   		<h1 class="text-center text-danger">Course Name : <?php echo htmlspecialchars($course_name_row['course_name']);  ?><a href="student_dashboard.php" class="btn btn-primary btn-md" style="float:right;">
   		Back
   	</a>

   </h1>
   		<?php
   	}
   	?>
   
   	
   
   	<table id="favCoursesTable" class="table table-striped table-hover">
                    <thead class="thead-dark">
                        <tr>
                            <th>File Name</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    	<?php 
						$sql = "SELECT * FROM course_file WHERE course_id = $course_id AND teacher_id = $teacher_id";
							$result = mysqli_query($conn, $sql);

							while ($row = mysqli_fetch_assoc($result)) {
							    echo '<tr>';
							    echo '<td>' . htmlspecialchars($row['file']) . '</td>';
							    echo '<td>
							            <a class="btn btn-warning btn-sm mx-1" href="' . htmlspecialchars($row['file']) . '" download>Download</a>
							          
							          </td>';
							    echo '</tr>';
							}
                    	?>
					
                      </tbody>
                </table>


			
<div id="courseChat" class="my-5">
    <div class="card shadow mb-4 p-4">
        <div class="container content">
            <div class="row">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <div class="card">
                        <div class="card-header">Chat</div>
                        <div class="card-body height3" style="width:100%!important">
	                            <ul class="chat-list list-unstyled">
							    <?php
							    // Check if there are any chat messages for this course and teacher
							    if (mysqli_num_rows($resultChat) > 0) {
							        // Fetch the chat data
							        while ($row = mysqli_fetch_assoc($resultChat)) {
							            // Decode the JSON stored in the 'chat' column
							            $chats = json_decode($row['chat'], true);
							            
							            // Loop through each message in the JSON array
							            foreach ($chats as $chat) {
							                ?>
							                <li class="in mb-3 d-flex justify-content-start">
							                    <div class="chat-body bg-light text-dark p-3 rounded shadow-sm"style="width: 100%;">
							                        <div class="chat-message">
							                            <!-- Display the date of the message -->
							                            <small class="text-muted">Date: <?php echo htmlspecialchars($chat['date']); ?></small>
							                            
							                            <!-- Display the student's name -->
							                            <h5 class="mb-1"><?php echo htmlspecialchars($chat['student_name']); ?></h5>
							                            
							                            <!-- Display the message content -->
							                            <p><?php echo htmlspecialchars($chat['message']); ?></p>
							                        </div>
							                    </div>
							                </li>
							                <?php
							            }
							        }
							    } else {
							        // No chat messages found
							        echo '<li><p>No chat messages yet.</p></li>';
							    }
							    ?>
							</ul>

                        </div>
                        <!-- Input box for new messages -->
                        <div class="card-footer">
                            <form method="POST" action="processChat.php">
                                <input type="hidden" name="course_id" value="<?php echo $course_id; ?>">
                                <input type="hidden" name="teacher_id" value="<?php echo $teacher_id; ?>">
                                <input type="hidden" name="student_name" value="<?php echo $studentcurt['name']; ?>">
                                <input type="hidden" name="student_id" value="<?php echo $studentcurt['id']; ?>">
                                <div class="input-group">
                                    <input type="text" name="message" class="form-control" placeholder="Type your message..." required>
                                    <div class="input-group-append">
                                        <button class="btn btn-primary" type="submit">Send</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>  
        </div>
    </div>
</div>

<!-- Add custom styling for chat messages -->
<style>
   
    .chat-body {
        max-width: 100%;
    }
    .out .chat-body {
        background-color: #007bff;
    }
    .in .chat-body {
        background-color: #f1f1f1;
    }
</style>



               
   <!-- Add Courses Tables Here -->

    <?php include('includes/footer.php') ?>
</body>

</html>