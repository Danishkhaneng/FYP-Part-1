<?php
session_start();
include 'php/db.php';

header('Content-Type: application/json');

if (!isset($_SESSION['student'])) {
    echo 'User not logged in.';
    exit();
}

$student_email = $_SESSION['student'];

// Fetch the student ID based on their email
$sql = "SELECT id FROM students WHERE email = '$student_email'";
$result = mysqli_query($conn, $sql);
$student = mysqli_fetch_assoc($result);
$student_id = $student['id'];

$sql = "SELECT c.id AS course_view_id, c.course_name AS course_name, c.description AS description, t.name AS teacher_name, t.id AS teacher_view_id, fc.id
        FROM saved_courses fc
        JOIN courses c ON fc.course_id = c.id
        JOIN teachers t ON fc.teacher_id = t.id
        WHERE fc.student_id = '$student_id'";

$result = mysqli_query($conn, $sql);

if (!$result) {
    echo json_encode(['error' => 'Database query failed']);
    exit();
}

$courses = [];
while ($row = mysqli_fetch_assoc($result)) {
    $courses[] = $row;
}

echo json_encode($courses);
?>
