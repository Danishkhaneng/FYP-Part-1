<?php
session_start();
include 'php/db.php';

if (!isset($_SESSION['student'])) {
    header('Location: index.php');
    exit();
}

$email = $_SESSION['student'];
$name = $_POST['name'];
$newEmail = $_POST['email'];
$contact = $_POST['contact'];
$oldPassword = $_POST['old_password'];
$newPassword = $_POST['password'];
$profileImage = $_FILES['profile_image'];

// Fetch the current student data
$sql = "SELECT * FROM students WHERE email = '$email'";
$result = mysqli_query($conn, $sql);
$student = mysqli_fetch_assoc($result);

$updateFields = [];
$errors = [];

// Check if old password matches before updating
if (!empty($newPassword)) {
    if (password_verify($oldPassword, $student['password'])) {
        $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
        $updateFields[] = "password = '$hashedPassword'";
    } else {
        echo "Old password is incorrect.";
        exit();
    }
}

// Check if email is unique
if ($newEmail != $email) {
    $sql = "SELECT * FROM students WHERE email = '$newEmail'";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0) {
        echo "Email address is already in use.";
        exit();
    } else {
        $updateFields[] = "email = '$newEmail'";
    }
}

// Handle profile image upload
if (!empty($profileImage['name'])) {
    $targetDir = "uploads/";
    $targetFile = $targetDir . time() . basename($profileImage['name']);
    $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));
    $allowedTypes = ['jpg', 'jpeg', 'png', 'gif'];

    // Check if file is an image and valid file type
    if (in_array($imageFileType, $allowedTypes)) {
        if (move_uploaded_file($profileImage['tmp_name'], $targetFile)) {
            // Add profile image path to update query
            $targetFile = $targetFile;
            $updateFields[] = "profile_image = '$targetFile'";
        } else {
            echo "Error uploading image.";
            exit();
        }
    } else {
        echo "Invalid file type. Only JPG, JPEG, PNG & GIF files are allowed.";
        exit();
    }
}

// Add name and contact to the update fields
$updateFields[] = "name = '$name'";
$updateFields[] = "contact = '$contact'";

// Construct the update query if there are fields to update
if (!empty($updateFields)) {
    $updateSql = "UPDATE students SET " . implode(', ', $updateFields) . " WHERE email = '$email'";

    if (mysqli_query($conn, $updateSql)) {
        // Update session email
        $_SESSION['student'] = $newEmail;
        echo 'Account information updated successfully!';
    } else {
        echo "Error updating account: " . mysqli_error($conn);
    }
} else {
    echo "No changes made.";
}

mysqli_close($conn);
?>
