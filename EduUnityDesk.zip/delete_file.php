<?php
include 'php/db.php';
session_start();

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Fetch the file name to delete from server
    $sql = "SELECT file FROM course_file WHERE id = $id";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    $file_name = $row['file'];

    // Delete from database
    $sql = "DELETE FROM course_file WHERE id = $id";
    mysqli_query($conn, $sql);

    // Delete from server
    unlink("uploads/" . $file_name);

            $_SESSION['message'] = "File Removed";

    header('Location: teacher_courses.php'); // Redirect back to file list
    exit();
}
?>
