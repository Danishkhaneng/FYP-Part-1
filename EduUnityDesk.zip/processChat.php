<?php
session_start();
include 'php/db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $course_id = $_POST['course_id'];
    $teacher_id = $_POST['teacher_id']; 
    $student_name = $_POST['student_name']; 
    $student_id = $_POST['student_id']; 
    $date = date('Y-m-d H:i:s'); // Current timestamp for message
    $message = mysqli_real_escape_string($conn, $_POST['message']); // Sanitize input

    // Create the new message as a JSON object
    $new_message = json_encode([
        'student_name' => $student_name,
        'date' => $date,
        'message' => $message,
        'student_id' => $student_id
    ]);

    // Check if the chat entry already exists for this course and teacher
    $check_sql = "SELECT chat FROM course_chat WHERE course_id = '$course_id' AND teacher_id = '$teacher_id'";
    $result = mysqli_query($conn, $check_sql);

    if (mysqli_num_rows($result) > 0) {
        // Entry exists, so update the JSON array with the new message
        $row = mysqli_fetch_assoc($result);
        $existing_chat = json_decode($row['chat'], true); // Decode existing JSON to array

        // Append the new message to the existing chat array
        $existing_chat[] = json_decode($new_message, true);

        // Encode back to JSON and update the database
        $updated_chat = mysqli_real_escape_string($conn, json_encode($existing_chat));
        $update_sql = "UPDATE course_chat SET chat = '$updated_chat' WHERE course_id = '$course_id' AND teacher_id = '$teacher_id'";
        
        if (mysqli_query($conn, $update_sql)) {
            $_SESSION['message'] = 'Message Updated';
            header('Location: student_course.php?course_id='.$course_id.'&teacher_id='.$teacher_id);
            exit();
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    } else {
        // Entry does not exist, insert a new one with the first message as JSON array
        $initial_chat = json_encode([json_decode($new_message, true)]); // Store as an array of one message
        $insert_sql = "INSERT INTO course_chat (course_id, teacher_id, chat) VALUES ('$course_id', '$teacher_id', '$initial_chat')";
        
        if (mysqli_query($conn, $insert_sql)) {
            $_SESSION['message'] = 'Message Sent';
            header('Location: student_course.php?course_id='.$course_id.'&teacher_id='.$teacher_id);
            exit();
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    }
}

mysqli_close($conn);
?>
