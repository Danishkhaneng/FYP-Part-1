<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: index.php');
    exit();
}

include '../php/db.php';

// Check if ID is provided
if (!isset($_GET['id'])) {
    die("No ID provided");
}

$id = $_GET['id'];

// Fetch the coordinator's current details
$sql = "SELECT * FROM admin WHERE id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, 'i', $id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (!$result || mysqli_num_rows($result) == 0) {
    die("Coordinator not found");
}

$coordinator = mysqli_fetch_assoc($result);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $password = $_POST['password'];
    $role = $_POST['role'];

    $check_sql = "SELECT * FROM admin WHERE name = '$name' and id != '$id'";
    $check_result = mysqli_query($conn, $check_sql);

     if (mysqli_num_rows($check_result) > 0) {
        // Name already exists
        $_SESSION['message'] = "Notice: Admin name already exists. Please choose a different name.";
          header('Location: edit_coordinator.php?id='.$id.'');
           exit();
    }

    // Prepare SQL statement to update coordinator details
    if (empty($password)) {
        // Update without changing the password
        $sql = "UPDATE admin SET name = ?, role = ? WHERE id = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, 'ssi', $name, $role, $id);
    } else {
        // Update with changing the password
        $sql = "UPDATE admin SET name = ?, password = ?, role = ? WHERE id = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, 'sssi', $name, $password, $role, $id);
    }

    if (mysqli_stmt_execute($stmt)) {
    	 $_SESSION['message'] = 'Coordinator Updated Successfully';
           header('Location: edit_coordinator.php?id='.$id.'');
           exit();
    } else {
        die("Error updating record: " . mysqli_error($conn));
    }

    mysqli_stmt_close($stmt);
}
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">

<?php include('includes/head.php') ?>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
            <?php include('includes/sidebar.php') ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

               <!-- Topbar -->
                <?php include('includes/topbar.php') ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">
                     <?php include('includes/show_message.php') ?>
                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">Edit Coordinator</h1>
                    <p class="mb-4">Update the details of the Coordinator.</p>

          
                         <form action="edit_coordinator.php?id=<?php echo $id; ?>" method="POST">
                            
                            <div class="form-group">
                                <label>Name</label>
                                <input type="text" name="name" class="form-control form-control-user" id="name" aria-describedby="name"
                                    value="<?php echo htmlspecialchars($coordinator['name']); ?>" required>
                            </div>
                            
                            <div class="form-group">
                                <label>Password</label>
                                <input type="password" name="password" class="form-control form-control-user" id="password" aria-describedby="password" placeholder="Leave blank to keep current password">
                            </div>

                            <div class="form-group">

                                <label>Role</label>
                            	 <select id="role" name="role" class="form-control form-control-user" required>
					                <option value="super" <?php echo $coordinator['role'] == 'super' ? 'selected' : ''; ?>>Super</option>
					                <option value="coordinator" <?php echo $coordinator['role'] == 'coordinator' ? 'selected' : ''; ?>>Coordinator</option>
					            </select>
                              
                            </div>
                            <button type="submit" class="btn btn-primary">Update Coordinator</button>
                        </form>

                <a class="btn btn-danger my-4" href="manage_coordinators.php">Back</a>

                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- End of Main Content -->


            
   
            <!-- Footer -->
                       <?php include('includes/footer.php') ?>

            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->


    <?php include('includes/logoutmodal.php') ?>
    <?php include('includes/scripts.php') ?>

</body>

</html>