<?php
include '../../php/db.php'; // Make sure this path is correct

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve data from POST request
    $course_name = mysqli_real_escape_string($conn, $_POST['course_name']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);

    // Insert data into database
    $sql = "INSERT INTO courses (course_name, description) VALUES ('$course_name', '$description')";
    if (mysqli_query($conn, $sql)) {
         session_start();
        $_SESSION['message'] = "Course added successfully.";
    } else {
        echo "Error adding course: " . mysqli_error($conn);
    }
}
?>