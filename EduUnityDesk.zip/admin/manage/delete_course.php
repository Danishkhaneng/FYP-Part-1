<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: ../login.php');
    exit();
}

include '../../php/db.php'; // Ensure the correct path

// Get the course ID from the URL
$id = $_GET['id'];

// Prepare and execute the delete query
$sql = "DELETE FROM courses WHERE id = $id";

if (mysqli_query($conn, $sql)) {
	 session_start();
        $_SESSION['message'] = 'Record Deleted';
        header('Location: ../manage_courses.php');
        exit();
} else {
    echo "Error deleting record: " . mysqli_error($conn);
}
?>
