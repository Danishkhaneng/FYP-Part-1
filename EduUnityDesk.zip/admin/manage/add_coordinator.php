<?php
include '../../php/db.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $password = md5($_POST['password']);
    $role = mysqli_real_escape_string($conn, $_POST['role']);

    // Check if the admin name already exists
    $check_sql = "SELECT * FROM admin WHERE name = '$name'";
    $check_result = mysqli_query($conn, $check_sql);

    if (mysqli_num_rows($check_result) > 0) {
        // Name already exists
        $_SESSION['message'] = "Notice: Admin name already exists. Please choose a different name.";
    } else {
        // Name is unique, proceed with insertion
        $insert_sql = "INSERT INTO admin (name, password, role) VALUES ('$name', '$password', '$role')";

        if (mysqli_query($conn, $insert_sql)) {
        	        $_SESSION['message'] = "Coordinator added successfully.";
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    }
} else {
    echo "Invalid request method.";
}

mysqli_close($conn);
?>
