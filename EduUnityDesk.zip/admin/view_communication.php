<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit();
}

include '../php/db.php';

// Get the communication ID from the URL
$communication_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Fetch the specific communication from the database
$sql = "SELECT c.*, s.name AS student_name , s.profile_image AS profile_image FROM communication c JOIN students s ON c.student_id = s.id WHERE c.id = $communication_id";
$result = mysqli_query($conn, $sql);
$communication = mysqli_fetch_assoc($result);

// Check if the query was successful
if (!$result || !$communication) {
    die("Error fetching communication: " . mysqli_error($conn));
}

// Fetch feedback
$feedback = json_decode($communication['feedback'], true) ?: [];

?>


<!DOCTYPE html>
<html lang="en">

<?php include('includes/head.php') ?>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
            <?php include('includes/sidebar.php') ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

               <!-- Topbar -->
                <?php include('includes/topbar.php') ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">
                	 <a href="manage_communication.php" class="btn btn-danger my-1" style="float: right;">Back</a>

                    <?php include('includes/show_message.php') ?>

                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">View Query</h1>
                    <p class="mb-4">View and manage query details.</p>

                    <div class="card shadow mb-4 p-4">
                    		<div class="card" style="width: 60%;">
							  <ul class="list-group list-group-flush">
							  	<li class="list-group-item"><strong>Query:</strong> <?php echo htmlspecialchars($communication['query']); ?></li>
							  	<li class="list-group-item"><strong>Status:</strong> <?php echo htmlspecialchars($communication['status']); ?></li>
							    <li class="list-group-item"><strong>Student Name:</strong> <?php echo htmlspecialchars($communication['student_name']); ?></li>
							    <li class="list-group-item"><strong>Voucher Number:</strong> <?php echo htmlspecialchars($communication['voucher_number']); ?></li>
							    <li class="list-group-item"><strong>Category:</strong>
												<?php
                                                        if ($communication['q_category'] == 'student_services') {
                                                           echo 'Student Services';
                                                        }elseif ($communication['q_category'] == 'admission_department') {
                                                            echo 'Admission Department';
                                                        }elseif ($communication['q_category'] == 'fees_department') {
                                                            echo 'Fees Department';
                                                        }

                                                        ?>
							    </li>
							    <li class="list-group-item"><strong>Coordinator:</strong> <?php echo htmlspecialchars($communication['q_coordinator']); ?></li>
							    
							  </ul>
							</div>
							  <form action="reply_communication.php" method="post">
  									<div class="form-group my-5">
  										<label class="text-danger"><strong>Change Query Status</strong></label>
                                   	<select class="form-control form-control-user" name="status" id="status">
					                	<option value="">Select Status</option>
					                	<option value="Resolved">Resolved</option>
					                </select>
                                   </div>
							<div class="container content">
							    <div class="row">
							        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
							        	<div class="card">
							        		<div class="card-header">Chat</div>
							        		<div class="card-body height3">
							        			<ul class="chat-list">
							        					<?php foreach ($feedback as $message) { 
							        							if ($message['role'] == 'admin') {
							        								?>
							        								<li class="out">
											        					<div class="chat-img">
											        						<img alt="Avtar" src="https://bootdey.com/img/Content/avatar/avatar6.png">
											        					</div>
											        					<div class="chat-body">
											        						<div class="chat-message">
											        							<h5><?php echo htmlspecialchars($message['message']); ?></h5>
											        							<p><?php echo htmlspecialchars($message['timestamp']); ?></p>
											        						</div>
											        					</div>
											        				</li>
							        								<?php
							        							}else{
							        								?>
							        								<li class="in">
											        					<div class="chat-img">
											        						<?php 
											        							if($communication['profile_image']){
											        								?>
											        								<img alt="Avtar" src="../<?php echo htmlspecialchars($communication['profile_image']); ?>">
											        								<?php
											        							}else{
											        								?>
											        								<img alt="Avtar" src="../uploads/default-profile.png">
											        								<?php
											        							}
											        						?>

											        						

											        					</div>
											        					<div class="chat-body">
											        						<div class="chat-message">
											        							<h5><?php echo htmlspecialchars($communication['student_name']); ?></h5>
											        							<p><?php echo htmlspecialchars($message['message']); ?></p>
											        						</div>
											        					</div>
											        				</li>
																	
							        								<?php
							        							}
							  								} ?>
							        			</ul>
									                <input type="hidden" name="communication_id" value="<?php echo htmlspecialchars($communication['id']); ?>">
									                <br>

									                <br>
									                 <div class="form-group">
			                                                <textarea name="reply" class="form-control form-control-user" placeholder="Type your reply here..." required></textarea>
			                                        </div>
			                                         
			                                         
			                                        <button class="btn btn-primary btn-sm" type="submit">Send</button>

							        		</div>
							        	</div>
							        </div>
							       
							</div>

		 
                    </div>
              </form>
         

                </div>
                 <a href="manage_communication.php" class="btn btn-danger my-1" style="float: left;">Back</a>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->


            <!-- Footer -->
                       <?php include('includes/footer.php') ?>

            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->


    <?php include('includes/logoutmodal.php') ?>
    <?php include('includes/scripts.php') ?>

</body>

</html>