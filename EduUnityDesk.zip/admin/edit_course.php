<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: index.php');
    exit();
}

include '../php/db.php'; // Ensure the correct path

// Get the course ID from the URL
$id = $_GET['id'];

// Fetch the course data
$sql = "SELECT * FROM courses WHERE id = $id";
$result = mysqli_query($conn, $sql);
$course = mysqli_fetch_assoc($result);

// Update the course if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $course_name = mysqli_real_escape_string($conn, $_POST['course_name']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);

    // Prepare the SQL query
    $update_sql = "UPDATE courses SET course_name='$course_name', description='$description' WHERE id = '$id'";

    if (mysqli_query($conn, $update_sql)) {
    	 $_SESSION['message'] = 'Course updated successfully';
            header('Location: edit_course.php?id='.$id.'');
            exit();
    } else {
        echo "Error updating record: " . mysqli_error($conn);
    }
}
?>


<!DOCTYPE html>
<html lang="en">

<?php include('includes/head.php') ?>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
            <?php include('includes/sidebar.php') ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

               <!-- Topbar -->
                <?php include('includes/topbar.php') ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">
                     <?php include('includes/show_message.php') ?>
                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">Edit Course</h1>
                    <p class="mb-4">Update the details of the Course.</p>

                         <form action="edit_course.php?id=<?php echo $course['id']; ?>" method="POST">
                            
                            <div class="form-group">
                                <label>Course Name</label>
                                <input type="text" name="course_name" class="form-control form-control-user" id="course_name" aria-describedby="course_name"
                                   value="<?php echo htmlspecialchars($course['course_name']); ?>" required>
                            </div>
                            
                            <div class="form-group">
                                <label>Description</label>
                                    <textarea class="form-control form-control-user" id="description" name="description" required><?php echo htmlspecialchars($course['description']); ?></textarea>
                            </div>

                            <button type="submit" class="btn btn-primary">Update Course</button>
                        </form>

                <a class="btn btn-danger my-4" href="manage_courses.php">Back</a>

                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- End of Main Content -->


            
   
            <!-- Footer -->
                       <?php include('includes/footer.php') ?>

            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->


    <?php include('includes/logoutmodal.php') ?>
    <?php include('includes/scripts.php') ?>

</body>

</html>