<?php
session_start();
$_GET['message'] = '';
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit();
}

include '../php/db.php';

// Fetch notices from the database
$sql = "SELECT * FROM notices ORDER BY date DESC";
$result = mysqli_query($conn, $sql);

// Check if the query was successful
if (!$result) {
    die("Error executing query: " . mysqli_error($conn));
}
?>


<!DOCTYPE html>
<html lang="en">

<?php include('includes/head.php') ?>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
            <?php include('includes/sidebar.php') ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

               <!-- Topbar -->
                <?php include('includes/topbar.php') ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <?php include('includes/show_message.php') ?>

                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">Manage Notices</h1>
                    <p class="mb-4">View and manage notices.</p>

                    <button class="btn btn-primary my-3" data-toggle="modal" data-target="#addNoticeModal">Add Notice</button>
                    <div class="card shadow mb-4">
                    
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>SNo.</th>
                                            <th>Image</th>
                                           <th>Title</th>
						                    <th>Content</th>
						                    <th>Date</th>
						                    <th class="actions">Actions</th>
                                        </tr>
                                    </thead>
                                    
                                    <tbody>
                                        <?php 
                                            $x = 1;
                                                 while($row = mysqli_fetch_assoc($result)) { ?>
                                            <tr>
                                                <td><?php echo $x; ?></td>
                                                <td><img src="../<?php echo $row['image']; ?>" alt="Notice Image" width="50"></td>
								                    <td><?php echo htmlspecialchars($row['title']); ?></td>
								                    <td>
												    <?php 
												    // Split the description by spaces and limit to 5 words
												    $words = explode(' ', $row['content']);
												    $first_five_words = implode(' ', array_slice($words, 0, 10));
												    echo htmlspecialchars($first_five_words) . (count($words) > 10 ? '...' : ''); 
												    ?>
												</td>
								                    <td><?php echo htmlspecialchars($row['date']); ?></td>
								                    

								                    <td class="actions">
								                        <a class="btn btn-primary btn-sm mx-1" href="edit_notice.php?id=<?php echo $row['id']; ?>">Edit</a>
								                        <a class="btn btn-danger btn-sm mx-1" href="manage/delete_notice.php?id=<?php echo $row['id']; ?>" class="delete" onclick="return confirm('Are you sure?')">Delete</a>
								                    </td>
                                               

                                            </tr>
                                            <?php 
                                            $x++;
                                        } 
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->


              <!-- Add Teacher Modal-->
                <div class="modal fade" id="addNoticeModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                    aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Add Notice</h5>
                                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">×</span>
                                </button>
                            </div>
                            <div class="modal-body">
              
 							<form id="noticeForm" method="POST" action="manage_notices.php" enctype="multipart/form-data"> 


 										<div class="form-group">
                                                                                    <label>Title</label>

                                            <input type="text" name="title" class="form-control form-control-user" id="title" aria-describedby="title"
                                                placeholder="Enter title" required>
                                        </div>
                                        
                                        <div class="form-group">
                                                                                    <label>Content</label>

            	                			<textarea class="form-control form-control-user" name="content" id="content" placeholder="Content" required></textarea>
                                        </div>

                                        <div class="form-group">
                                                                                    <label>Date</label>

                                            <input type="date" name="date" class="form-control form-control-user" id="date"
                                                placeholder="Enter Date" required>
                                        </div>

                                        <div class="form-group">
                                                                                    <label>Image</label>

                                            <input type="file" name="image" class="form-control form-control-user" id="image" accept="image/*"
                                                placeholder="Enter image" required>
                                        </div>
										<button class="btn btn-primary"  type="submit" name="add_notice">Save Notice</button>

                                    </form>
                            </div>  
                            <div class="modal-footer">
                                <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                            </div>
                        </div>
                    </div>
                </div>
                     <script>
                 

                    // Submit form
                    document.getElementById('noticeForm').addEventListener('submit', function(event) {
                        event.preventDefault();
                        
                        var formData = new FormData(this);
                        
                        fetch('manage/add_notice.php', {
                            method: 'POST',
                            body: formData
                        })
                        .then(response => response.text())
                        .then(result => {
                                                       location.reload(); // Refresh page to show new data


                        })
                        .catch(error => console.error('Error:', error));
                    });
                </script>
 
   
            <!-- Footer -->
                       <?php include('includes/footer.php') ?>

            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->


    <?php include('includes/logoutmodal.php') ?>
    <?php include('includes/scripts.php') ?>

</body>

</html>