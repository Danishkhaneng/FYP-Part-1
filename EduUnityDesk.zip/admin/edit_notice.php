<?php
session_start();
include '../php/db.php';

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit();
}

$id = $_GET['id'];

// Fetch the notice details
$sql = "SELECT * FROM notices WHERE id = $id";
$result = mysqli_query($conn, $sql);
$notice = mysqli_fetch_assoc($result);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $content = $_POST['content'];
    $date = $_POST['date'];

    // Handle image upload
    if ($_FILES['image']['name']) {
        $target_dir = "../uploads/";

        // Generate a unique name for the image
        $image = uniqid() . "_" . basename($_FILES['image']['name']);
        $target_file = $target_dir . $image;

        // Upload the image
        if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
            $image_url = "uploads/" . $image; // Update image path for database storage
            $update_sql = "UPDATE notices SET title='$title', content='$content', date='$date', image='$image_url' WHERE id = $id";
        } else {
        	 $_SESSION['message'] = 'Error uploading image';
            exit();
        }
    } else {
        $update_sql = "UPDATE notices SET title='$title', content='$content', date='$date' WHERE id = $id";
    }

    // Execute query and check for errors
    if (mysqli_query($conn, $update_sql)) {
    	$_SESSION['message'] = 'Notice updated successfully';
        header("Location: manage_notices.php");
    } else {
        echo "Error updating notice: " . mysqli_error($conn);
    }
}

mysqli_close($conn);
?>


<!DOCTYPE html>
<html lang="en">

<?php include('includes/head.php') ?>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
            <?php include('includes/sidebar.php') ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

               <!-- Topbar -->
                <?php include('includes/topbar.php') ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">
                     <?php include('includes/show_message.php') ?>
                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">Edit Notice</h1>
                    <p class="mb-4">Update the details of the notice.</p>

                         <form action="edit_notice.php?id=<?php echo $notice['id']; ?>" method="POST" enctype="multipart/form-data">
                            
                            <div class="form-group">
                                <label>Title</label>
                                <input type="text" name="title" class="form-control form-control-user" id="title" aria-describedby="title"
                                    value="<?php echo htmlspecialchars($notice['title']); ?>" required>
                            </div>
                            
                            <div class="form-group">
                                                                <label>Content</label>

                                    <textarea  class="form-control form-control-user" id="content" name="content" required><?php echo htmlspecialchars($notice['content']); ?></textarea>
                            </div>

                            <div class="form-group">
                                                                <label>Date</label>

                                <input type="date" name="date" class="form-control form-control-user" id="date"
                                    value="<?php echo htmlspecialchars($notice['date']); ?>" required>
                            </div>

                            <div class="form-group">
                                                                <label>Image</label>

                                <input type="file" name="image" class="form-control form-control-user" id="image"
                                    value="<?php echo htmlspecialchars($notice['image']); ?>" required accept="image/*">
                            </div> 

                            <div class="form-group">
                                 <p>Current Image:</p>
				            <?php if ($notice['image']) { ?>
				                <img src="../<?php echo htmlspecialchars($notice['image']); ?>" alt="Current Image" width="100">
				            <?php } else { ?>
				                <p>No image uploaded</p>
				            <?php } ?>
                            </div>
                            

                            <button type="submit" class="btn btn-primary">Update Notice</button>
                        </form>

	                <a class="btn btn-danger my-4" href="manage_notices.php">Back</a>

                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- End of Main Content -->


            
   
            <!-- Footer -->
                       <?php include('includes/footer.php') ?>

            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->


    <?php include('includes/logoutmodal.php') ?>
    <?php include('includes/scripts.php') ?>

</body>

</html>