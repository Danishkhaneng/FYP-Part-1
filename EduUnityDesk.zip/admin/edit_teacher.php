<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit();
}

include '../php/db.php'; // Adjust the path if necessary

// Check if the teacher ID is provided
if (isset($_GET['id'])) {
    $teacher_id = intval($_GET['id']);

    // Fetch the teacher's current data
    $sql = "SELECT * FROM teachers WHERE id = $teacher_id";
    $result = mysqli_query($conn, $sql);

    if ($result && mysqli_num_rows($result) > 0) {
        $teacher = mysqli_fetch_assoc($result);
    } else {
        die("Teacher not found.");
    }

    // Fetch courses for the dropdown
    $course_sql = "SELECT id, course_name FROM courses";
    $course_result = mysqli_query($conn, $course_sql);

    // Check if the form is submitted
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $name = $_POST['name'];
        $email = $_POST['email'];
        $contact = $_POST['contact'];
        $experience = $_POST['experience'];
        $course_id = $_POST['course_id'];
        $password = $_POST['password'];

            $email_check_sql = "SELECT * FROM teachers WHERE email = '$email' AND id != '$teacher_id'";
            $email_check_result = mysqli_query($conn, $email_check_sql);
            if (mysqli_num_rows($email_check_result) > 0) {
                $_SESSION['message'] = 'Notice: Email already exists.';
                header('Location: edit_teacher.php?id='.$teacher_id.'');
                exit;
            }

        if(!empty($password)){
        $update_sql = "UPDATE teachers SET email='$email', password='$password', name='$name', contact='$contact', experience='$experience', course_id='$course_id' WHERE id=$teacher_id";
        }else{
             $update_sql = "UPDATE teachers SET email='$email', name='$name', contact='$contact', experience='$experience', course_id='$course_id' WHERE id=$teacher_id";
        }

    

        if (mysqli_query($conn, $update_sql)) {
            $_SESSION['message'] = 'Teacher Updated Successfully';
            header('Location: edit_teacher.php?id='.$teacher_id.'');
            exit();
        } else {
            die("Error updating teacher: " . mysqli_error($conn));
        }
    }
} else {
    header('Location: manage_teachers.php');
    exit();
}
?>


<!DOCTYPE html>
<html lang="en">

<?php include('includes/head.php') ?>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
            <?php include('includes/sidebar.php') ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

               <!-- Topbar -->
                <?php include('includes/topbar.php') ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">
                     <?php include('includes/show_message.php') ?>
                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">Edit Teacher</h1>
                    <p class="mb-4">Update the details of the teacher.</p>

                         <form action="edit_teacher.php?id=<?php echo $teacher['id']; ?>" method="POST">
                            
                            <div class="form-group">
                                <label>Email :</label>
                                <input type="email" name="email" class="form-control form-control-user" id="email" aria-describedby="email"
                                    value="<?php echo htmlspecialchars($teacher['email']); ?>" required>
                            </div>

                            <div class="form-group">
                                <label>Name :</label>
                                <input type="text" name="name" class="form-control form-control-user" id="name" aria-describedby="name"
                                    value="<?php echo htmlspecialchars($teacher['name']); ?>" required>
                            </div>

                            <div class="form-group">
                                <label>Password :</label>
                                <input type="password" name="password" class="form-control form-control-user" id="password" aria-describedby="password">
                            </div>
                            
                            <div class="form-group">
                                <label>Contact :</label>
                                <input type="text" name="contact" class="form-control form-control-user" id="contact" aria-describedby="contact"
                                    value="<?php echo htmlspecialchars($teacher['contact']); ?>" required>
                            </div>

                            <div class="form-group">
                                <label>Experience :</label>
                                <input type="number" name="experience" class="form-control form-control-user" id="experience"
                                    value="<?php echo htmlspecialchars($teacher['experience']); ?>" required>
                            </div>

                            <div class="form-group">
                                <label>Course :</label>
                               <select name="course_id" class="form-control form-control-user" required>
                                     <option value="" disabled>Select Course</option>
                                    <?php while ($course = mysqli_fetch_assoc($course_result)) { ?>
                                        <option value="<?php echo $course['id']; ?>" <?php echo ($course['id'] == $teacher['course_id']) ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($course['course_name']); ?>
                                        </option>
                                    <?php } ?>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-primary">Update Teacher</button>
                        </form>

                <a class="btn btn-danger my-4" href="manage_teachers.php">Back</a>

                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- End of Main Content -->


            
   
            <!-- Footer -->
                       <?php include('includes/footer.php') ?>

            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->


    <?php include('includes/logoutmodal.php') ?>
    <?php include('includes/scripts.php') ?>

</body>

</html>