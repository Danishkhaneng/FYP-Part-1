<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.php">
                <div class="sidebar-brand-icon rotate-n-15">
                    <i class="fas fa-laugh-wink"></i>
                </div>
                <div class="sidebar-brand-text mx-3">Edu Unity Desk</div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" href="index.php">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span></a>
            </li>  

            <li class="nav-item active">
                <a class="nav-link" href="manage_teachers.php">
                    <i class="fas fa-chalkboard-teacher"></i>
                    <span>Teachers</span>
                </a>
            </li>  

            <li class="nav-item active">
                <a class="nav-link" href="manage_students.php">
                    <i class="fas fa-user-graduate"></i>
                    <span>Students</span>
                </a>
            </li>

            <li class="nav-item active">
                <a class="nav-link" href="manage_courses.php">
                    <i class="fas fa-book-open"></i>
                    <span>Courses</span>
                </a>
            </li>

            <li class="nav-item active">
                <a class="nav-link" href="manage_communication.php">
                    <i class="fas fa-comments"></i>
                    <span>Queries</span>
                </a>
            </li>

            <li class="nav-item active">
                <a class="nav-link" href="manage_saved_courses.php">
                    <i class="fas fa-heart"></i>
                    <span>Saved Courses</span>
                </a>
            </li>

            <li class="nav-item active">
                <a class="nav-link" href="manage_notices.php">
                    <i class="fas fa-bell"></i>
                    <span>Notices</span>
                </a>
            </li>

            <?php if (isset($_SESSION['role']) && $_SESSION['role'] == 'super') { ?>
             <li class="nav-item active">
                        <a class="nav-link" href="manage_coordinators.php">
                            <i class="fas fa-user-tie"></i>
                            <span>Coordinators</span>
                        </a>
                    </li>

            <?php } ?>

            <!-- Divider -->
            <hr class="sidebar-divider">

          
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>
    

        </ul>