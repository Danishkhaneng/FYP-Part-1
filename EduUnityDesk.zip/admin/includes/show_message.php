<?php if (isset($_SESSION['message']) && !empty($_SESSION['message'])): ?>
                            <div id="messagesShow">
                                 <p class="bg-danger text-white p-3"><?php echo htmlspecialchars($_SESSION['message']); ?></p>
                            </div>
                        <?php
                        $_SESSION['message'] = ''; 
                    endif; ?>