<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit();
}

include '../php/db.php';

// Fetch saved courses from the database along with student names and course names
$sql = "SELECT sc.student_id, s.name AS student_name, sc.course_id, c.course_name, t.name As teacher_name
        FROM saved_courses sc
        JOIN students s ON sc.student_id = s.id
        JOIN teachers t ON sc.teacher_id = t.id
        JOIN courses c ON sc.course_id = c.id";
$result = mysqli_query($conn, $sql);

// Check if the query was successful
if (!$result) {
    die("Error executing query: " . mysqli_error($conn));
}
?>


<!DOCTYPE html>
<html lang="en">

<?php include('includes/head.php') ?>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
            <?php include('includes/sidebar.php') ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

               <!-- Topbar -->
                <?php include('includes/topbar.php') ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <?php include('includes/show_message.php') ?>

                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">Manage Saved Courses</h1>
                    <p class="mb-4">View and manage saved courses details.</p>

                    <div class="card shadow mb-4">
                    
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>SNo.</th>
                                            <th>Student Name</th>
						                    <th>Course Name</th>
						                    <th>Teacher Name</th>
						                    <th class="actions">Actions</th>
                                        </tr>
                                    </thead>
                                    
                                    <tbody>
                                        <?php 
                                            $x = 1;
                                                 while($row = mysqli_fetch_assoc($result)) { ?>
                                            <tr>
                                                <td><?php echo $x; ?></td>
                                                 <td><?php echo htmlspecialchars($row['student_name']); ?></td>
							                    <td><?php echo htmlspecialchars($row['course_name']); ?></td>
							                    <td><?php echo htmlspecialchars($row['teacher_name']); ?></td>
							                    <td class="actions">
							                       <a class="btn btn-primary btn-sm mx-1" href="manage/delete_saved_course.php?student_id=<?php echo $row['student_id']; ?>&course_id=<?php echo $row['course_id']; ?>" class="delete" onclick="return confirm('Are you sure?')">Delete</a>

							                    </td>
                                            </tr>
                                            <?php 
                                            $x++;
                                        } 
                                           
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->


              <!-- Add Teacher Modal-->
                <div class="modal fade" id="addTeacherModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                    aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Add New Teacher</h5>
                                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">×</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form id="teacherForm">
                                        <div class="form-group">
                                            <input type="text" name="name" class="form-control form-control-user" id="name" aria-describedby="name"
                                                placeholder="Enter Name" required>
                                        </div>
                                        
                                        <div class="form-group">
                                            <input type="name" name="contact" class="form-control form-control-user" id="contact" aria-describedby="contact"
                                                placeholder="Enter Contact" required>
                                        </div>

                                        <div class="form-group">
                                            <input type="number" name="experience" class="form-control form-control-user" id="experience"
                                                placeholder="Enter Experience" required>
                                        </div>

                                        <div class="form-group">
                                           <select name="course_id" class="form-control form-control-user" required>
                                                <option value="" disabled selected>Select Course</option>
                                                <?php while ($course = mysqli_fetch_assoc($course_result)) { ?>
                                                    <option value="<?php echo htmlspecialchars($course['id']); ?>">
                                                        <?php echo htmlspecialchars($course['course_name']); ?>
                                                    </option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                        <button class="btn btn-primary" type="submit">Add</button>
                                    </form>
                            </div>  
                            <div class="modal-footer">
                                <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                            </div>
                        </div>
                    </div>
                </div>
                     <script>
                 

                    // Submit form
                    document.getElementById('teacherForm').addEventListener('submit', function(event) {
                        event.preventDefault();
                        
                        var formData = new FormData(this);
                        
                        fetch('manage/add_teacher.php', {
                            method: 'POST',
                            body: formData
                        })
                        .then(response => response.text())
                        .then(result => {
                                                       location.reload(); // Refresh page to show new data


                        })
                        .catch(error => console.error('Error:', error));
                    });
                </script>
 
   
            <!-- Footer -->
                       <?php include('includes/footer.php') ?>

            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->


    <?php include('includes/logoutmodal.php') ?>
    <?php include('includes/scripts.php') ?>

</body>

</html>