<!DOCTYPE html>
<html lang="en">

<?php include('includes/head.php') ?>
<?php
if (!isset($_SESSION['student'])) {
    header('Location: index.php');
    exit();
}
?>

<body>
    <?php include('includes/spinner.php') ?>
    <?php include('includes/navbar.php') ?>
    <?php include('includes/notices.php') ?>
    <?php include('includes/footer.php') ?>
</body>

</html>