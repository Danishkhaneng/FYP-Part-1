<?php 
include 'php/db.php';

?>
<!-- Navbar Start -->
<nav class="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0">
    <a href="index.php" class="navbar-brand d-flex align-items-center px-4 px-lg-5">
        <h2 class="m-0 text-primary"><i class="fa fa-book me-3"></i>Edu Unity Desk</h2>
    </a>
    <button type="button" class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarCollapse">
        <div class="navbar-nav ms-auto p-4 p-lg-0">
            <a href="index.php" class="nav-item nav-link active">Home</a>
            <a href="about.php" class="nav-item nav-link">About</a>
            <a href="notice.php" class="nav-item nav-link">Notices</a>
        </div>
         <?php
            if (!isset($_SESSION['student']) && !isset($_SESSION['teacher'])) {
               ?>
                <a href="#" class="btn btn-primary py-4 px-lg-5 d-none d-lg-block" data-bs-toggle="modal" data-bs-target="#loginModal">
                    Sign In - Student<i class="fa fa-arrow-right ms-3"></i>
                </a>
                <a href="#" class="btn btn-danger py-4 px-lg-5 d-none d-lg-block" data-bs-toggle="modal" data-bs-target="#registerModal">
                    Register - Student<i class="fa fa-arrow-right ms-3"></i>
                </a>
               <?php
            }
            if (!isset($_SESSION['teacher']) && !isset($_SESSION['student'])) {
               ?>
                <a href="#" class="btn btn-warning py-4 px-lg-5 d-none d-lg-block" data-bs-toggle="modal" data-bs-target="#loginModalTeacher">
                    Sign In - Teacher<i class="fa fa-arrow-right ms-3"></i>
                </a>
               <?php
            }
            if (isset($_SESSION['student'])) {
                $email1 = $_SESSION['student'];
               
               ?>
               <a href="student_dashboard.php" class="btn btn-primary py-4 px-lg-5 d-none d-lg-block">
                    Student Dashboard<i class="fa fa-arrow-right ms-3"></i></a>
                <a href="logout.php" class="btn btn-warning py-4 px-lg-5 d-none d-lg-block">
                    Logout<i class="fa fa-arrow-right ms-3"></i></a>
               <?php
               if (!empty($email1)) {
                    $query = "SELECT profile_image FROM students WHERE email = '$email1'";
                $result = mysqli_query($conn, $query);
                                   $row = mysqli_fetch_assoc($result);

                   $profileImage = $row['profile_image'] ? $row['profile_image'] : 'uploads/default-profile.png';
                   ?>
                   <a href="student_dashboard.php" class=" px-lg-5 d-none d-lg-block">
                    <img src="<?php echo $profileImage; ?>" alt="Profile Image" class="rounded-circle" style="width: 40px; height: 40px; object-fit: cover;">
                        </a>
                   <?php
               }
            }
            if (isset($_SESSION['teacher'])) {
                 $email2 = $_SESSION['teacher'];
                   
               ?>
               <a href="teacher_dashboard.php" class="btn btn-primary py-4 px-lg-5 d-none d-lg-block">
                    Teacher Dashboard<i class="fa fa-arrow-right ms-3"></i></a>
                <a href="logout.php" class="btn btn-warning py-4 px-lg-5 d-none d-lg-block">
                    Logout<i class="fa fa-arrow-right ms-3"></i></a>
               <?php
               if ($email2) {
                    $query1 = "SELECT profile_image FROM teachers WHERE email = '$email2'";
                    $result1 = mysqli_query($conn, $query1);
                                       $row1 = mysqli_fetch_assoc($result1);

                   $profileImage1 = $row1['profile_image'] ? $row1['profile_image'] : 'uploads/default-profile.png';
                   ?>
                   <a href="teacher_dashboard.php" class=" px-lg-5 d-none d-lg-block">
                    <img src="<?php echo $profileImage1; ?>" alt="Profile Image" class="rounded-circle" style="width: 40px; height: 40px; object-fit: cover;">
                        </a>
                   <?php
               }
            }
        ?>

       
    </div>
</nav>
<!-- Navbar End -->

<!-- Login Modal Start Teacher -->
<div class="modal fade" id="loginModalTeacher" tabindex="-1" aria-labelledby="loginModalTeacherLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="loginModalTeacherLabel">Sign In - Teacher</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="loginTeacher.php" method="POST">
                    <div class="mb-3">
                        <label for="email" class="form-label">Email address</label>
                        <input type="email" name="email" class="form-control" id="email" placeholder="Enter your email">
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" name="password" class="form-control" id="password" placeholder="Enter your password">
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Sign In</button>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- Login Modal End -->
<!-- Login Modal Start -->
<div class="modal fade" id="loginModal" tabindex="-1" aria-labelledby="loginModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="loginModalLabel">Sign In - Student</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="login.php" method="POST">
                    <div class="mb-3">
                        <label for="email" class="form-label">Email address</label>
                        <input type="email" name="email" class="form-control" id="email" placeholder="Enter your email">
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" name="password" class="form-control" id="password" placeholder="Enter your password">
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Sign In</button>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- Login Modal End -->



<!-- Register Modal Start -->
<div class="modal fade" id="registerModal" tabindex="-1" aria-labelledby="registerModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="registerModalLabel">Register - Student</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form method="POST" action="register.php">
                    <div class="mb-4">
                        <label for="name" class="form-label">Full Name</label>
                        <input type="text" class="form-control" name="name" id="name" >
                    </div>
                    <div class="mb-4">
                        <label for="reg_no" class="form-label">Registration Number</label>
                        <input type="text" class="form-control" name="reg_no" id="reg_no" >
                    </div>
                    <div class="mb-4">
                        <label for="email" class="form-label">Email address</label>
                        <input type="email" class="form-control" name="email" id="email" >
                    </div>
                    <div class="mb-4">
                        <label for="text" class="form-label">Phone Number</label>
                        <input type="contact" class="form-control" name="contact" id="contact" >
                    </div>
                    <div class="mb-4">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" name="password" id="password">
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Register</button>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- Register Modal End -->