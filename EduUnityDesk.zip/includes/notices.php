<?php
include 'php/db.php';

// Fetch latest notices from the database
$sql = "SELECT * FROM notices ORDER BY date DESC";  
$result = mysqli_query($conn, $sql);
?>

<div class="container-xxl py-5">
    <div class="container">
        <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
            <h2 class="section-title bg-white text-center text-primary px-3">Notices</h2>
        </div>
        <div class="row g-4 justify-content-center">
        	
            <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="course-item bg-light">
                        <div class="position-relative overflow-hidden">
                            <img class="img-fluid" src="../<?php echo $row['image']; ?>" alt="">
                            <div class="w-100 d-flex justify-content-center position-absolute bottom-0 start-0 mb-4">
                                <!-- Button to trigger modal -->
                                <a href="#" class="flex-shrink-0 btn btn-sm btn-primary px-3 border-end" style="border-radius: 30px;" 
                                data-bs-toggle="modal" data-bs-target="#noticeModal<?php echo $row['id']; ?>">Read More</a>
                            </div>
                        </div>
                        <div class="text-center p-4 pb-0">
                            <h5 class="mb-4"><?php echo htmlspecialchars($row['title']); ?></h5>
                            <p class="mb-4"><?php echo htmlspecialchars(substr($row['content'], 0, 100)); ?>...</p>
                        </div>
                        <div class="text-center py-3">
                            <small><i class="far fa-calendar-alt text-primary"></i><?php echo date("d M, Y", strtotime($row['date'])); ?></small>
                        </div>
                    </div>
                </div>

                <!-- Modal -->
                <div class="modal fade" id="noticeModal<?php echo $row['id']; ?>" tabindex="-1" aria-labelledby="noticeModalLabel<?php echo $row['id']; ?>" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="noticeModalLabel<?php echo $row['id']; ?>"><?php echo htmlspecialchars($row['title']); ?></h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <img class="img-fluid my-3" src="../<?php echo $row['image']; ?>" alt="">
                                 <small class="py-5"><i class="far fa-calendar-alt text-primary"></i><?php echo date("d M, Y", strtotime($row['date'])); ?></small>
                                <p><?php echo nl2br(htmlspecialchars($row['content'])); ?></p>
                            </div>
                            <div class="modal-footer">
                               
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            </div>
                        </div>
                    </div>
                </div>
            <?php } ?>
           
        </div>
    </div>
</div>

<?php
mysqli_close($conn);
?>
