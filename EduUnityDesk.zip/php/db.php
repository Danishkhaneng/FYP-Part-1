<?php
$host = 'sql313.infinityfree.com';
$dbname = 'if0_37269061_eduUnityDesk';
$user = 'if0_37269061';
$pass = 'kddqolT6VDiEO';

$conn = mysqli_connect($host, $user, $pass, $dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
