-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql313.infinityfree.com
-- Generation Time: Oct 30, 2024 at 02:28 PM
-- Server version: 10.6.19-MariaDB
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `if0_37269061_eduUnityDesk`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `password`, `role`) VALUES
(2, 'admin', 'admin123', 'super'),
(9, 'Coordinator 1', '202cb962ac59075b964b07152d234b70', 'coordinator'),
(10, 'Coordinator 2', '202cb962ac59075b964b07152d234b70', 'coordinator'),
(11, 'Coordinator 3', '202cb962ac59075b964b07152d234b70', 'coordinator');

-- --------------------------------------------------------

--
-- Table structure for table `communication`
--

CREATE TABLE `communication` (
  `id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `query` text DEFAULT NULL,
  `voucher_number` varchar(255) DEFAULT NULL,
  `feedback` text DEFAULT NULL,
  `q_category` varchar(255) NOT NULL,
  `q_coordinator` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `communication`
--

INSERT INTO `communication` (`id`, `student_id`, `query`, `voucher_number`, `feedback`, `q_category`, `q_coordinator`, `status`) VALUES
(26, 19, 'hello', '#1774', '[{\"role\":\"admin\",\"message\":\"Hi, How Can I help You\",\"timestamp\":\"2024-09-29 06:34:44\"},{\"role\":\"student\",\"message\":\"All good\",\"timestamp\":\"2024-09-29 06:34:59\"},{\"role\":\"admin\",\"message\":\"Resolved\",\"timestamp\":\"2024-09-29 06:35:15\"}]', 'admission_department', 'adminas', 'Resolved'),
(27, 19, 'hi 1', '#3222', '[]', 'admission_department', 'Coordinator 1', 'pending'),
(28, 23, 'query2', '#5310', '[]', 'student_services', 'Coordinator 2', 'pending'),
(29, 25, 'query3', '#9114', '[{\"role\":\"admin\",\"message\":\"done\",\"timestamp\":\"2024-10-04 16:29:40\"},{\"role\":\"student\",\"message\":\"ok\",\"timestamp\":\"2024-10-04 16:31:52\"},{\"role\":\"admin\",\"message\":\"yes\",\"timestamp\":\"2024-10-04 16:33:39\"}]', 'student_services', 'Coordinator 3', 'Resolved');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `id` int(11) NOT NULL,
  `course_name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`id`, `course_name`, `description`, `created_at`) VALUES
(8, 'English', 'asd', '2024-09-22 07:37:03'),
(9, 'Math', 'tytyt', '2024-09-22 07:37:11');

-- --------------------------------------------------------

--
-- Table structure for table `course_chat`
--

CREATE TABLE `course_chat` (
  `id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `chat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `course_chat`
--

INSERT INTO `course_chat` (`id`, `course_id`, `teacher_id`, `chat`) VALUES
(4, 9, 4, '[{\"student_name\":\"zaid\",\"date\":\"2024-09-22 13:50:17\",\"message\":\"sda\"},{\"student_name\":\"zaid\",\"date\":\"2024-09-22 13:51:58\",\"message\":\"hello\"},{\"student_name\":\"zaid\",\"date\":\"2024-09-22 13:52:06\",\"message\":\"how are you\"},{\"student_name\":\"jawad\",\"date\":\"2024-09-22 13:53:04\",\"message\":\"Hi I asdoaisnasdasd \"},{\"student_name\":\"jawad\",\"date\":\"2024-09-22 13:53:13\",\"message\":\"asdasdsad\"},{\"student_name\":\"jawad\",\"date\":\"2024-09-22 14:03:35\",\"message\":\"asdasdas\",\"student_id\":\"17\"},{\"student_name\":\"zaid\",\"date\":\"2024-09-22 19:46:40\",\"message\":\"asd\",\"student_id\":\"16\"},{\"student_name\":\"zaid\",\"date\":\"2024-09-22 19:46:57\",\"message\":\"asd\",\"student_id\":\"16\"}]'),
(5, 8, 1, '[{\"student_name\":\"zaid\",\"date\":\"2024-10-04 16:23:49\",\"message\":\"hello\",\"student_id\":\"19\"},{\"student_name\":\"test3\",\"date\":\"2024-10-04 16:35:54\",\"message\":\"hi\",\"student_id\":\"25\"}]');

-- --------------------------------------------------------

--
-- Table structure for table `course_file`
--

CREATE TABLE `course_file` (
  `id` int(11) NOT NULL,
  `file` varchar(255) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `course_file`
--

INSERT INTO `course_file` (`id`, `file`, `teacher_id`, `course_id`) VALUES
(8, 'uploads/1.pdf', 4, 9),
(9, 'uploads/1.pdf', 3, 9),
(10, 'uploads/1 (1)_1727002407.pdf', 4, 9);

-- --------------------------------------------------------

--
-- Table structure for table `notices`
--

CREATE TABLE `notices` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `date` date DEFAULT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notices`
--

INSERT INTO `notices` (`id`, `title`, `content`, `date`, `image`) VALUES
(3, 'Notice 1', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. In in ex consectetur, sodales lacus eget, volutpat nunc. Proin sollicitudin nisl nisi, nec congue diam blandit eu. Donec faucibus justo ut varius bibendum. Suspendisse lobortis ornare mi a vehicula. Pellentesque nec risus ac enim vulputate tempus sed nec sem. Vestibulum vel felis a metus fermentum egestas. Etiam molestie ornare metus. Donec vestibulum nibh sed tortor facilisis, ut finibus urna iaculis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Nullam consectetur eleifend massa, in elementum nunc. Donec semper, justo vitae maximus convallis, ex nisi aliquam erat, scelerisque sagittis magna est a erat. Duis eget feugiat sem. Duis ac ultricies nisi, non elementum urna. Nam bibendum magna arcu, a sodales elit placerat rutrum. Etiam bibendum placerat nisi a malesuada.', '2024-10-05', 'uploads/66e6df8a005e7_stem-list-EVgsAbL51Rk-unsplash1-min-1024x576.jpg'),
(4, 'Notice 3', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. In in ex consectetur, sodales lacus eget, volutpat nunc. Proin sollicitudin nisl nisi, nec congue diam blandit eu. Donec faucibus justo ut varius bibendum. Suspendisse lobortis ornare mi a vehicula. Pellentesque nec risus ac enim vulputate tempus sed nec sem. Vestibulum vel felis a metus fermentum egestas. Etiam molestie ornare metus. Donec vestibulum nibh sed tortor facilisis, ut finibus urna iaculis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Nullam consectetur eleifend massa, in elementum nunc. Donec semper, justo vitae maximus convallis, ex nisi aliquam erat, scelerisque sagittis magna est a erat. Duis eget feugiat sem. Duis ac ultricies nisi, non elementum urna. Nam bibendum magna arcu, a sodales elit placerat rutrum. Etiam bibendum placerat nisi a malesuada.', '2024-10-04', 'uploads/66e6e03e6d2dd_stem-list-EVgsAbL51Rk-unsplash1-min-1024x576.jpg'),
(5, 'Notice 4', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. In in ex consectetur, sodales lacus eget, volutpat nunc. Proin sollicitudin nisl nisi, nec congue diam blandit eu. Donec faucibus justo ut varius bibendum. Suspendisse lobortis ornare mi a vehicula. Pellentesque nec risus ac enim vulputate tempus sed nec sem. Vestibulum vel felis a metus fermentum egestas. Etiam molestie ornare metus. Donec vestibulum nibh sed tortor facilisis, ut finibus urna iaculis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Nullam consectetur eleifend massa, in elementum nunc. Donec semper, justo vitae maximus convallis, ex nisi aliquam erat, scelerisque sagittis magna est a erat. Duis eget feugiat sem. Duis ac ultricies nisi, non elementum urna. Nam bibendum magna arcu, a sodales elit placerat rutrum. Etiam bibendum placerat nisi a malesuada.', '2024-09-27', 'uploads/66e6dfbb15e4f_Conference-Audience-Clapping-Feature-Image.jpg'),
(6, 'Notice ', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. In in ex consectetur, sodales lacus eget, volutpat nunc. Proin sollicitudin nisl nisi, nec congue diam blandit eu. Donec faucibus justo ut varius bibendum. Suspendisse lobortis ornare mi a vehicula. Pellentesque nec risus ac enim vulputate tempus sed nec sem. Vestibulum vel felis a metus fermentum egestas. Etiam molestie ornare metus. Donec vestibulum nibh sed tortor facilisis, ut finibus urna iaculis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Nullam consectetur eleifend massa, in elementum nunc. Donec semper, justo vitae maximus convallis, ex nisi aliquam erat, scelerisque sagittis magna est a erat. Duis eget feugiat sem. Duis ac ultricies nisi, non elementum urna. Nam bibendum magna arcu, a sodales elit placerat rutrum. Etiam bibendum placerat nisi a malesuada.', '2024-09-12', 'uploads/66e6dfce385bf_alphagamma-bett-show-2020-opportuniries-min-1024x576.jpg'),
(7, 'Notice 6', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. In in ex consectetur, sodales lacus eget, volutpat nunc. Proin sollicitudin nisl nisi, nec congue diam blandit eu. Donec faucibus justo ut varius bibendum. Suspendisse lobortis ornare mi a vehicula. Pellentesque nec risus ac enim vulputate tempus sed nec sem. Vestibulum vel felis a metus fermentum egestas. Etiam molestie ornare metus. Donec vestibulum nibh sed tortor facilisis, ut finibus urna iaculis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Nullam consectetur eleifend massa, in elementum nunc. Donec semper, justo vitae maximus convallis, ex nisi aliquam erat, scelerisque sagittis magna est a erat. Duis eget feugiat sem. Duis ac ultricies nisi, non elementum urna. Nam bibendum magna arcu, a sodales elit placerat rutrum. Etiam bibendum placerat nisi a malesuada.', '2024-09-20', 'uploads/66e6dff05395f_28032023012127PM-Shutterstock_2129585300-min.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `saved_courses`
--

CREATE TABLE `saved_courses` (
  `id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `course_id` int(11) DEFAULT NULL,
  `teacher_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `saved_courses`
--

INSERT INTO `saved_courses` (`id`, `student_id`, `course_id`, `teacher_id`) VALUES
(29, 19, 8, 1),
(30, 25, 8, 1);

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `contact` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `profile_image` varchar(255) NOT NULL,
  `reg_no` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `name`, `email`, `contact`, `password`, `profile_image`, `reg_no`, `status`) VALUES
(19, 'zaid', 'zaid@gmail.com', '123', '$2y$10$lXDwkgEmJtIiWCJFcagSfe4K3.3oiUoMGkO0C8aWZucyjH.lp5oLu', 'uploads/17295340381a (2).png', 'zaid-fa12', 'approved'),
(22, 'newTest', 'newTest@gmail.com', '123', '$2y$10$mLfov0T3VW3WdxE9abtyd.mygWmgdSnkB8ib2KFsmY6VIusUnDzuS', '', 'Fa12378', 'approved'),
(23, 'danish', 'danish@gmail.com', '099998', '$2y$10$INeMkjk51FLvcAz/tfTsnel9A8x3a/iOC4L3vSM1CTcTQ/k0w8MVm', 'uploads/1728074230me.jpeg', '009', 'approved'),
(24, 'mk', 'mk@gmail.com', '01', '$2y$10$OIHZuHbTCrhh17MG3sct1Oz3TbjsDndbCP8iyF.RHv5XEJqRlwe62', '', '2', 'approved'),
(25, 'test3', 'test3@gmail.com', '03', '$2y$10$WxTY/VjPuhl3gikgyaSBHe2.OVU4XPnT6VX1LzZc1r/ILuG.Cf09K', '', '3', 'approved');

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE `teachers` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `experience` varchar(255) DEFAULT NULL,
  `course_id` int(11) DEFAULT NULL,
  `profile_image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`id`, `email`, `password`, `name`, `contact`, `experience`, `course_id`, `profile_image`) VALUES
(1, 'sohail@gmail.com', '123', 'Sohail', '123', '3', 8, '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `communication`
--
ALTER TABLE `communication`
  ADD PRIMARY KEY (`id`),
  ADD KEY `communication_ibfk_1` (`student_id`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `course_chat`
--
ALTER TABLE `course_chat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `course_file`
--
ALTER TABLE `course_file`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notices`
--
ALTER TABLE `notices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `saved_courses`
--
ALTER TABLE `saved_courses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `saved_courses_ibfk_2` (`course_id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `communication`
--
ALTER TABLE `communication`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `course_chat`
--
ALTER TABLE `course_chat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `course_file`
--
ALTER TABLE `course_file`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `notices`
--
ALTER TABLE `notices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `saved_courses`
--
ALTER TABLE `saved_courses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `teachers`
--
ALTER TABLE `teachers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `communication`
--
ALTER TABLE `communication`
  ADD CONSTRAINT `communication_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `saved_courses`
--
ALTER TABLE `saved_courses`
  ADD CONSTRAINT `saved_courses_ibfk_2` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
