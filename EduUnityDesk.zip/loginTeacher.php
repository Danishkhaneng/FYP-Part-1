<?php
include 'php/db.php';
session_start();
if (isset($_SESSION['student']) || isset($_SESSION['teacher'])) {
    header('Location: index.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    $sql = "SELECT * FROM teachers WHERE email='$email'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        $teacher = mysqli_fetch_assoc($result);
        
        // Verify the password
        if ($password == $teacher['password']) {
            $_SESSION['teacher'] = $teacher['email'];
            $_SESSION['id'] = $teacher['id'];
            $_SESSION['message'] = 'Welcome Back!';
            header('Location: teacher_dashboard.php');
            exit();
        } else {
             $_SESSION['message'] = 'Incorrect password!';
            header('Location: index.php');
            exit();
        }
    } else {
         $_SESSION['message'] = 'No account found with this email!';
            header('Location: index.php');
            exit();
    }
}
mysqli_close($conn);
?>
