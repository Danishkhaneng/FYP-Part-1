<?php
session_start();
include 'php/db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $teacher_id = $_POST['teacher_id']; // Make sure to store teacher ID in the session
    $course_id = $_POST['course_id']; // Assume you pass course ID through a hidden field

    // Handle file upload
    if (isset($_FILES['file']) && $_FILES['file']['error'] == 0) {
        $original_file_name = $_FILES['file']['name'];
        $file_tmp = $_FILES['file']['tmp_name'];
        $file_type = pathinfo($original_file_name, PATHINFO_EXTENSION);

        // Check if the file is a PDF
        if ($file_type === 'pdf') {
            // Generate a new file name with timestamp
            $timestamp = time(); // Current timestamp
            $file_name = pathinfo($original_file_name, PATHINFO_FILENAME) . '_' . $timestamp . '.' . $file_type;
            $file_path = "uploads/" . $file_name; // Store full path

            // Move the uploaded file to the directory
            move_uploaded_file($file_tmp, $file_path);

            // Insert file information into the database
            $sql = "INSERT INTO course_file (file, teacher_id, course_id) VALUES ('$file_path', '$teacher_id', '$course_id')";
            mysqli_query($conn, $sql);
            $_SESSION['message'] = "File Added";
            header('Location: teacher_courses.php'); // Redirect to list page
            exit();
        } else {
            $_SESSION['message'] = "Only PDF files are allowed.";
            header('Location: teacher_courses.php'); // Redirect to list page
            exit();
        }
    }
}
?>
