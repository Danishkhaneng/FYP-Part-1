<?php
// remove_from_favourites.php
include 'php/db.php'; // Include the database connection

// Check if course ID is provided via POST
if (isset($_POST['course_id'])) {
    $course_id = $_POST['course_id'];

    // Delete the course from saved_courses table for the logged-in student
    $sql = "DELETE FROM saved_courses WHERE id = '$course_id'";
    
    if (mysqli_query($conn, $sql)) {
        echo "Course removed from favourites successfully!";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>
