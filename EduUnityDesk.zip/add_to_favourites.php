<?php
session_start();
include 'php/db.php';

if (!isset($_SESSION['student'])) {
    echo 'User not logged in.';
    exit();
}

$student_email = $_SESSION['student'];

// Fetch the student ID based on their email
$sql = "SELECT id FROM students WHERE email = '$student_email'";
$result = mysqli_query($conn, $sql);
$student = mysqli_fetch_assoc($result);
$student_id = $student['id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $course_id = $_POST['course_id'];
    $teacher_id = $_POST['teacher_id'];

    // Check if the course is already added to favourites
    $check_sql = "SELECT * FROM saved_courses WHERE student_id = '$student_id' AND course_id = '$course_id' AND teacher_id = '$teacher_id'";
    $check_result = mysqli_query($conn, $check_sql);

    if (mysqli_num_rows($check_result) > 0) {
        echo 'This course is already in your favourites.';
    } else {
        // Insert the course into the saved_courses table
        $insert_sql = "INSERT INTO saved_courses (student_id, course_id, teacher_id) VALUES ('$student_id', '$course_id', '$teacher_id')";
        if (mysqli_query($conn, $insert_sql)) {
            echo 'Course added to favourites successfully!';
        } else {
            echo 'Error adding course to favourites: ' . mysqli_error($conn);
        }
    }
} else {
    echo 'Invalid request.';
}
?>
